<?php
/**
 * Affiche le chaque livre dont l'id est dans le tableau $_SESSION['panier'] avec possibilité de retirer des id
 */
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['first_name'] sont bien definie
   if(!(isset($_SESSION['id_user']) && isset($_SESSION['first_name_user']))) {
      header("Location: connexion.php");
        exit();
    }
    function removeElementsFromArray($array, $elementToRemove) {
        $newArray = [];
        foreach ($array as $item) {
          if ($item !== $elementToRemove) {
            $newArray[] = $item;
          }
        }
        return $newArray;
      }

    $idTab = $_SESSION['panier'];
    if (isset($_GET['id']) ) {
          $idTab = removeElementsFromArray($idTab, $_GET['id']);
          $_SESSION['panier'] = $idTab;
          header("Location: panier.php?succes= Suppression du panier a été bien effectué");
          exit();
    }
    $chaineId = implode(';',$_SESSION['panier']);
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Recherche d'utilisateurs</title>
  <!-- <link rel="stylesheet" href="../CSS/styleAdminHome.css" /> -->
  <link rel="stylesheet" href="../CSS/styleUserHome.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&family=Roboto:wght@100;300;400;500;700;900&display=swap"
    rel="stylesheet" />
    <link rel="shortcut icon" href="../Image/logo.svg" type="image/x-icon">
</head>

<body>

  <div class="global-container">

  <nav class="side-nav">
      <div class="nav-logo">
        <img src="../Image/logo.svg">
        <h1>Read<?php echo "<span id=\"namecolor\">Ease"; ?></span></h1>
      </div>

      <a href="userHome.php" class="bloc-link">
        <img src="../Image/home.png">
        <span class="nav-links">Acceuil</span>
      </a>
      <a href="panier.php" class="bloc-link active">
        <img src="../Image/shopping-online.png">
        <span class="nav-links">Panier  <?= count($_SESSION['panier'])?></span>
      </a>
      <a href="displayEnpreintUser.php" class="bloc-link">
        <img src="../Image/pile-de-livres.png">
        <span class="nav-links">Livre Enpreinté</span>
      </a>
    </nav>

    <main class="main-content">
    <div class="container-flex">
        <h2 class="bv"><?php echo "Utilisateur <span id=\"namecolor\">".$_SESSION['first_name_user']." ".$_SESSION['last_name_user']; ?></span></h2>
        <button type="button" id="deco"><a href="userHome.php">Acceuil</a></button>
    </div>
      <h2 class="main-title">Votre panier</h2>
      <?php if(isset($_GET['succes1'])){?>
              <p id="succes"><?php echo $_GET['succes1'] ?></p>
      <?php }else{?> 
      <?php 
              if (count($idTab) >= 1){
                echo "<button  class=\"validePanier\" ><a href=\"ajoutEnpreint.php?idTab=$chaineId\">Valider mon panier</a> </button>";
              }else{ 
                echo "<p id=\"erreur\">Votre panier est vide</p>";
              }
              if (isset($_GET['succes'])){
                echo "<p id=\"succes1\">".$_GET['succes']."</p>";
              }
            }
      ?>
      <table class="table">
        <tr>
          <th>Image</th>
          <th>Nom du livre</th>
          <th>Année de publication</th>
          <th>Retiré</th>
        </tr>
        <?php
            $i = 0;
            while ($i < count($idTab)) {
                try {
                    $id = $idTab[$i];
                    $dsn = "mysql:host=localhost;dbname=projet_webl2";
                    $connexion = new PDO($dsn, "root", "");
                    $recup = $connexion->query("SELECT * FROM book WHERE id = '$id';");
                    $resultat = $recup->fetch();
                      echo "<tr>";
                      echo "<td><img src=\"".$resultat['img']."\" width=\"60px\"></td>";
                      echo "<td>".$resultat['title']."</td>";
                      echo "<td>".$resultat['publication_year']."</td>";
                      echo "<td><a  href=\"panier.php?id=".$resultat['id']."\"><span id=\"retirer\">Retirer</span></a></td>";
                      echo "</tr>";
                  }catch(PDOException $e) {
                      exit('Erreur : '.$e->getMessage());
                  } 
                  $i++;
              }
        ?>
      </table>

    </main>
  </div>
</body>
</html>