<?php
    session_start();
    if(!(isset($_SESSION['id_admin']) && isset($_SESSION['first_name_admin']))) {
        header("Location: connexion.php");
            exit();
    }
    //cette fonction renvoie une valeur valide
    function validate($data){
        $data = trim($data);// "trim()" supprime les espaces vides au début et à la fin de la chaîne.
        $data = stripslashes($data);//supprime les barres obliques inverses ("") de la chaîne (eviter des failles de securiter)
        $data = htmlspecialchars($data);//convertit les caractères spéciaux en entités HTML (eviter les injection de code dans le formulaire)
        return $data;
    }
    $first_name= validate($_POST["first_name"]);
    $last_name= validate($_POST["last_name"]);
    $birth_date = validate($_POST["birth_date"]);
    $email= validate($_POST["email"]);
    $pwd= validate($_POST["pwd"]);
    if (isset($_POST["statue"]) && !empty($_POST["statue"])) {
            $statue = $_POST["statue"] ;
    } 
    $hashedPassword = password_hash($pwd, PASSWORD_DEFAULT);
    if (empty($first_name) || empty($last_name) || empty($birth_date) 
        || empty($email) || empty($pwd) || empty($statue) ){
            header("Location: addUser.php?error= Veuillez remplir tous les champs, s'il vous plaît."); 
             exit();
    }
    try {
        $dsn = "mysql:host=localhost;dbname=projet_webl2";
        $connexion = new PDO($dsn, "root", "");
        $req = "SELECT * FROM users where first_name = '$first_name' AND last_name = '$last_name'";
        $res = $connexion->query($req);
        if($res->rowCount() > 0) {
            header("Location: addUser.php?error= Cette utilisateur est déja enregistrer."); 
             exit();
        }
        $requete = "INSERT INTO users (first_name,last_name,birth_date,email,password, statue)
                    VALUES (:first_name, :last_name, :birth_date, :email, :password , :statue)";
         $connexion->prepare($requete)->execute(array(
            ':first_name' => $first_name,
            ':last_name' => $last_name,
            ':birth_date' => $birth_date,
            ':email' => $email,
            ':password' => $pwd,
            ':statue' => $statue
        ));
        header("Location: addUser.php?succes=  Votre Inscription à bien été effectué !"); 
             exit();
    }catch(PDOException $e) {
    exit('Erreur : '.$e->getMessage());
    } 
?>