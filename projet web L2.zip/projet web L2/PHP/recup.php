<?php
/**
 * Envoie toutes les informations qui sont dans la table livre en format JSON qui sera recuperer par les fichier JS
 */
session_start();
//Pour ne pas que tout le monde puisse accédé a ces données
if (isset($_SESSION['id_user']) || isset($_SESSION['id_admin'])){
// Connexion à la base de données avec PDO
$dsn = 'mysql:host=localhost;dbname=projet_webl2';
$username = 'root';
$password = '';

try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connexion échouée : ' . $e->getMessage();
}

// Récupération des données depuis la base de données
$stmt = $pdo->query('SELECT * FROM book');
$livres = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Envoi des données au format JSON
header('Content-Type: application/json');
echo json_encode($livres);
}else{
    header("Location: connexion.php");
    exit();
}
?>
