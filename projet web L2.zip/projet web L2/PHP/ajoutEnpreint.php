<?php
/**
 * Ajout dans la table loan tout en mettant à jour les données book et loan
 */
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['first_name'] sont bien definie
   if(!(isset($_SESSION['id_user']) && isset($_SESSION['first_name_user']))) {
        header("Location: connexion.php");
        exit();
    }
    if (isset($_GET['idTab'])) {
        $idTab = explode(';', $_GET['idTab']);
        $i = 0;
        $dsn = "mysql:host=localhost;dbname=projet_webl2";
        $connexion = new PDO($dsn, "root", "");
        $_SESSION['panier'] = [];
        while ($i < count($idTab)) {
            $search = "SELECT * FROM loan WHERE book_id = $idTab[$i]";
            $resultSearch = $connexion->query($search);
            if ($resultSearch->rowCount() === 1) {
                $update = "UPDATE loan SET qte = qte + 1 WHERE book_id = $idTab[$i]";
                $resultUpdate = $connexion->query($update);
            }else {
                $dateToday = date("Y-m-d");
                $date = new DateTime();
                // Vérifier le statut de l'utilisateur et modifier la date en conséquence
                if ($_SESSION['statue'] === "utilisateur") {
                    $date->modify('+2 weeks'); // Ajouter 2 semaines
                } elseif ($_SESSION['statue_user'] === "premium") {
                    $date->modify('+1 month'); // Ajouter 1 mois
                }
                // Formatter la date selon le format désiré
                $dateFormatted = $date->format('Y-m-d');
                $userId = $_SESSION['id_user'];
                $req = "INSERT INTO loan (book_id, user_id, start_date, end_date, qte) VALUES ($idTab[$i], $userId, '$dateToday', '$dateFormatted', 1)";
                $connexion->query($req);

                $update2 = "UPDATE book SET stock = stock - 1 WHERE id = " . $idTab[$i];
                $connexion->query($update2);
                
            }
            $i++;
        }
        header("Location:panier.php?succes1=Nous vous remercions votre panier a été valider avec succes!");
        exit();
    }
?>
