<?php
    
    session_start();

    // Effacer toutes les variables de session
    session_unset();

    // Détruire la session
    session_destroy();

    //apres fermeture de la session nous renvoie sur la page index.php
    header("location: connexion.php");
?>