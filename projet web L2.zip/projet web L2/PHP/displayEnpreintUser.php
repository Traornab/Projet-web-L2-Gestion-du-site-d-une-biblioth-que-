<?php
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['first_name'] sont bien definie
   if(!(isset($_SESSION['id_user']) && isset($_SESSION['first_name_user']))) {
        header("Location: connexion.php");
        exit();
    }
?>


<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Recherche d'utilisateurs</title>
  <!-- <link rel="stylesheet" href="../CSS/styleAdminHome.css" /> -->
  <link rel="stylesheet" href="../CSS/styleUserHome.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&family=Roboto:wght@100;300;400;500;700;900&display=swap"
    rel="stylesheet" />
    <link rel="shortcut icon" href="../Image/logo.svg" type="image/x-icon">
<script src="../JS/displayDynamiqueUserEnpreint.js" defer></script>

</head>

<body>

  <div class="global-container">

    <nav class="side-nav">
    <div class="nav-logo">
        <img src="../Image/logo.svg">
        <h1>Read<?php echo "<span id=\"namecolor\">Ease"; ?></span></h1>
      </div>
      <a href="userHome.php" class="bloc-link">
        <img src="../Image/home.png">
        <span class="nav-links">Acceuil</span>
      </a>
      <a href="panier.php" class="bloc-link ">
        <img src="../Image/shopping-online.png">
        <span class="nav-links">Panier  <?= count($_SESSION['panier'])?></span>
      </a>
      <a href="" class="bloc-link active">
        <img src="../Image/pile-de-livres.png">
        <span class="nav-links">Livre Enpreinté</span>
      </a>
    </nav>

    <main class="main-content">
    <div class="container-flex">
        <div class="input-control">
            <label for="search">
            <img src="../Image/search.svg">
            </label>
            <input type="text" id="search" placeholder="Recherche">
        </div>
        <h2 class="bv"><?php echo "Utilisateur <span id=\"namecolor\">".$_SESSION['first_name_user']." ".$_SESSION['last_name_user']; ?></span></h2>
        <button type="button" id="deco"><a href="deconnexion.php">Déconnexion</a></button>
    </div>
      <h2 class="main-title">Livres enpreintés</h2>
      <?php if(isset($_GET['succes'])){?>
          <p id="succes"><?php echo $_GET['succes'] ?></p>
      <?php }?>
      <table class="table">
        <tr>
          <th>Image</th>
          <th>Nom du livre</th>
          <th>Date de debut</th>
          <th>Date de fin</th>
          <th>Quantité</th>
          <th>Renouveler</th>
          <th>Rendre</th>
        </tr>
      </table>

    </main>

  </div>
</body>

</html>