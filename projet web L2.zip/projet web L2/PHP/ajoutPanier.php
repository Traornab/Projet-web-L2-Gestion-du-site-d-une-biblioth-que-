<?php
/**
 * ajout l'id du livre qui ce trouve dans $_SESSION['tmp'] dans le tableau $_SESSION['panier']
 */
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['first_name'] sont bien definie
   if(!(isset($_SESSION['id_user']) && isset($_SESSION['first_name_user']))) {
    header("Location: connexion.php");
        exit();
    }
    function addElementToArrayIfNotExists($array, $elementToAdd) {
        if (!in_array($elementToAdd, $array)) {
            $array[] = $elementToAdd; // Ajouter l'élément au tableau uniquement s'il n'existe pas déjà
        }
        return $array;
    }
    if (isset($_SESSION['tmp'])) {
        $_SESSION['panier'] = addElementToArrayIfNotExists($_SESSION['panier'], $_SESSION['tmp']);
        header("Location: userHome.php?succes=Ajout au panier effectué avec succes!");
        exit();
    }
?>