<?php
    session_start();
    if(!(isset($_SESSION['id_admin']) && isset($_SESSION['first_name_admin']))) {
        header("Location: connexion.php");
            exit();
    }
    //cette fonction renvoie une valeur valide
    function validate($data){
        $data = trim($data);// "trim()" supprime les espaces vides au début et à la fin de la chaîne.
        $data = stripslashes($data);//supprime les barres obliques inverses ("") de la chaîne (eviter des failles de securiter)
        $data = htmlspecialchars($data);//convertit les caractères spéciaux en entités HTML (eviter les injection de code dans le formulaire)
        return $data;
    }
    $title= validate($_POST["title"]);
    $author= validate($_POST["author"]);
    $publisher = validate($_POST["publisher"]);
    $publication_year= validate($_POST["publication_year"]);
    $category= validate($_POST["category"]);
    $stock= $_POST["stock"];
    $summary = validate($_POST["summary"]);
    $img = validate($_POST["img"]);
    if (empty($img) || empty($summary) || empty($stock) 
        || empty($category) || empty($publication_year) 
        || empty($publisher) || empty($author) || empty($title)){
            header("Location: addUser.php?error= Veuillez remplir tous les champs, s'il vous plaît."); 
             exit();
    }

    try {
        $dsn = "mysql:host=localhost;dbname=projet_webl2";
        $connexion = new PDO($dsn, "root", "");
        $req = "SELECT * FROM book where title = '$title' AND author = '$author'";
        $res = $connexion->query($req);
        if($res->rowCount() > 0) {
            header("Location: addUser.php?error= ce livre est déja enregistrer."); 
             exit();
        }
        $req = "INSERT INTO book (title, author, publisher, publication_year, category, stock, summary, img)
                VALUES (:title, :author, :publisher, :publication_year, :category , :stock, :summary, :img)";
        $connexion->prepare($req)->execute(array(
            ':title' => $title,
            ':author' => $author,
            ':publisher' => $publisher,
            ':publication_year' => $publication_year,
            ':category' => $category,
            ':stock' => $stock,
            ':summary' => $summary,
            ':img' => $img
        ));
        header("Location: addUser.php?succes=  Le livre à bien été effectué !"); 
             exit();
    }catch(PDOException $e) {
    exit('Erreur : '.$e->getMessage());
    } 
?>