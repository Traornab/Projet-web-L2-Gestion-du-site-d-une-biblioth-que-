<?php
/**
 * Rend un livre => augmente le stocke de ce livre et supprime ce livre de la table loan pour l'utilisateur voulant rendre le livre
 */
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['first_name'] sont bien definie
   if(!(isset($_SESSION['id_user']) && isset($_SESSION['first_name_user']))) {
        header("Location: connexion.php");
        exit();
    }
    $loan_id = $_GET['loan_id'];
    $book_id = $_GET['book_id'];
    $qte = $_GET['qte'];
    try {
        $dsn = "mysql:host=localhost;dbname=projet_webl2";
        $connexion = new PDO($dsn, "root", "");
        $requete = "UPDATE book SET stock = stock+$qte WHERE id = $book_id";
        $connexion->query($requete);
        $requete1 = "DELETE FROM loan WHERE loan_id = $loan_id;";         
        $connexion->query($requete1);
        header("Location: displayEnpreintUser.php?succes= Votre livre a été rendu avec secces!"); 
        exit();
    }catch(PDOException $e) {
        exit('Erreur : '.$e->getMessage());
    }
?>