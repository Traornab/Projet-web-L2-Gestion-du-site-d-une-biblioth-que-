<?php
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['admi_email'] sont bien definie
   if(!(isset($_SESSION['id_admin']) && isset($_SESSION['first_name_admin']))) {
    header("Location: connexion.php");
        exit();
   }
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Recherche d'utilisateurs</title>
  <link rel="stylesheet" href="../CSS/addUser.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&family=Roboto:wght@100;300;400;500;700;900&display=swap"
    rel="stylesheet" />
    <link rel="shortcut icon" href="../Image/logo.svg" type="image/x-icon">
</head>

<body>

    <div class="global-container">

        <nav class="side-nav">
            <div class="nav-logo">
                <img src="../Image/logo.svg">
                <h1>Admin</h1>
            </div>
            <a href="addUser.php" class="bloc-link active">
                <img src="../Image/dashboard.svg">
                <span class="nav-links">Ajout</span>
            </a>
            <a href="displayUser.php" class="bloc-link">
                <img src="../Image/profil.png">
                <span class="nav-links">utilisateurs</span>
            </a>
            <a href="adminHome.php" class="bloc-link ">
                <img src="../Image/pile-de-livres.png">
                <span class="nav-links">Livres</span>
            </a>
            <a href="displayEnpreint.php" class="bloc-link">
                <img src="../Image/calendar.svg">
                <span class="nav-links">Livres Empruntés</span>
            </a>
        </nav>
   
    </div>
    <div class="btn">
        <a href="addUser.php" class="btn-inscription bon">Ajout utilisateur</a>
        <a href="addBook.php" class="btn-inscription">Ajout Livre</a>
    </div>
    <div class="form">
                <div class="container">
                    <form action="gestionAddUser.php" method="POST">
                        <h1 id="h1">INSCRIPTION UTILISATEUR</h1>

                        <!--Methode get pour pouvoire chercher le message d'erreur dans l'url et l'afficher au dessus du formulaire en cas d'erreur-->
                        <?php if(isset($_GET['error'])){?>
                            <p id="error"><?php echo $_GET['error'] ?></p>
                        <?php }?>
                        <?php if(isset($_GET['succes'])){?>
                            <p id="succes"><?php echo $_GET['succes'] ?></p>
                        <?php }?>
                        <input type="text" id="first_name" name="first_name" placeholder="Nom" required>
                        <input type="text" id="last_name" name="last_name" placeholder="Prenom" required></br>
                        <input type="date" id="birth_date" placeholder="date"  name="birth_date">
                        <input type="email" name="email" placeholder="Email">
                        <input type="password" name="pwd" placeholder="Mot de passe"></br>
                        <select id="section" name="statue">
                            <option value="utilisateur">UTILISATEUR</option>
                            <option value="admin">ADMIN</option>
                            <option value="premium">PREMIUM</option>
                        </select>
                        <input  id="sub" type="submit" name="inscription" value="Inscription">
                    </form>
                </div>
    </div>
   
    
</body>

</html>
