<?php
/**
 * Modifie les données d'un livre par l'admin
 */
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['admi_email'] sont bien definie
   if(!(isset($_SESSION['id_admin']) && isset($_SESSION['first_name_admin']))) {
        header("Location: connexion.php");
        exit();
    }
    if(isset($_GET['id']) && !empty($_GET['id'])){
            // Cette fonction renvoie une valeur valide sans modifier la chaîne d'origine.
        function validate($data){
            $trimmed_data = trim($data); // "trim()" supprime les espaces vides au début et à la fin de la chaîne.
            $stripped_data = stripslashes($trimmed_data); // Supprime les barres obliques inverses ("") de la chaîne (évite les failles de sécurité).
            $html_encoded_data = htmlspecialchars($stripped_data); // Convertit les caractères spéciaux en entités HTML (évite les injections de code dans le formulaire).
            return $html_encoded_data; // Retourne la chaîne de caractères validée.
        }
        $id = $_GET['id']; 
        if(isset($_POST['suppLivre'])){
            try {
                $dsn = "mysql:host=localhost;dbname=projet_webl2";
                $connexion = new PDO($dsn, "root", "");
                $requete1 = "DELETE FROM book WHERE id = '$id';";         
                $connexion->query($requete1);
                header("Location: adminHome.php?succes= Suppression réaliser avec succes!"); 
                exit();
            }catch(PDOException $e) {
                exit('Erreur : '.$e->getMessage());
            }   
        }else{
            try {
            $dsn = "mysql:host=localhost;dbname=projet_webl2";
            $connexion = new PDO($dsn, "root", "");
            $recup = $connexion->query("SELECT * FROM book WHERE id = '$id';");
            $resultat = $recup->fetch();
            }catch(PDOException $e) {
                exit('Erreur : '.$e->getMessage());
            } 
            $img = str_replace('<br />','', $resultat['img']);
            $summary = str_replace('<br />','', $resultat['Summary']);//pour recuperer tous les balises br au cas où et est ermplacer par '' 
            $stock = $resultat['stock'];
            $category = $resultat['category'];
            $publication_year = $resultat['publication_year'];
            $publisher = $resultat['publisher'];
            $author = $resultat['author'];
            $title = $resultat['title'];
                if (isset($_POST["img"]) && isset($_POST['summary']) && isset($_POST['stock']) 
                    && isset($_POST['category']) && isset($_POST['publication_year']) 
                    && isset($_POST['publisher']) && isset($_POST['author']) 
                    && isset($_POST['title']) && isset($_POST['modifLivre'])){
                $img_saisie = validate(str_replace('<br />','',$_POST["img"]));
                $summary_saisie = validate(str_replace('<br />','', $_POST['summary']));//pour recuperer tous les balises br au cas où et est ermplacer par '' 
                $stock_saisie = $_POST['stock'];
                $category_saisie = validate($_POST['category']);
                $publication_year_saisie = validate( $_POST['publication_year']);
                $publisher_saisie = validate($_POST['publisher']);
                $author_saisie = validate($_POST['author']);
                $title_saisie = validate($_POST['title']);
                $choix = $_POST['modifLivre'];
                if($choix == 'Modifier'){
                    try {
                        $req = "UPDATE book SET title = :title, author = :author, publisher = :publisher,
                                publication_year = :publication_year, category = :category, stock = :stock,
                                summary = :summary, img = :img WHERE id = :id;";
                        $connexion->prepare($req)->execute(array(
                            ':title' => $title_saisie,
                            ':author' => $author_saisie,
                            ':publisher' => $publisher_saisie,
                            ':publication_year' => $publication_year_saisie,
                            ':category' => $category_saisie,
                            ':stock' => $stock_saisie,
                            ':summary' => $summary_saisie,
                            ':img' => $img_saisie,
                            ':id' => $id
                        ));
                        header("Location: adminHome.php?succes= Modification réaliser avec succes!"); 
                        exit();
                    }catch(PDOException $e) {
                        exit('Erreur : '.$e->getMessage());
                    }   
                }
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Ajout de livres</title>
  <link rel="stylesheet" href="../CSS/addUser.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&family=Roboto:wght@100;300;400;500;700;900&display=swap"
    rel="stylesheet" />
    <link rel="shortcut icon" href="../Image/logo.svg" type="image/x-icon">
</head>

<body>

    <div class="global-container">

        <nav class="side-nav">
            <div class="nav-logo">
                <img src="../Image/logo.svg">
                <h1>Admin</h1>
            </div>

            <a href="addUser.php" class="bloc-link">
                <img src="../Image/dashboard.svg">
                <span class="nav-links">Ajout</span>
            </a>
            <a href="displayUser.php" class="bloc-link">
                <img src="../Image/profil.png">
                <span class="nav-links">utilisateur</span>
            </a>
            <a href="adminHome.php" class="bloc-link active">
            <img src="../Image/pile-de-livres.png">
                <span class="nav-links">Modification livre</span>
            </a>
            <a href="displayEnpreint.php" class="bloc-link">
                <img src="../Image/calendar.svg">
                <span class="nav-links">Livres Empruntés</span>
            </a>
        </nav>
   
    </div>
    <div class="btn">
        <a href="adminHome.php" class="btn-inscription1">Retour a la base de donnée</a>
    </div>
    <div class="form">
                <div class="container">
                    <form action="" method="POST">
                        <h1 id="h1">MODIFICATION LIVRE</h1>
                        <!--Methode get pour pouvoire chercher le message d'erreur dans l'url et l'afficher au dessus du formulaire en cas d'erreur-->
                        <?php if(isset($_GET['error'])){?>
                            <p id="error"><?php echo $_GET['error'] ?></p>
                        <?php }?>
                        <input type="text"  name="title" placeholder="Titre" value="<?= $title ?>" required>
                        <input type="text"  name="author" placeholder="Auteur" value="<?= $author ?>" required>
                        <input type="text"  name="publisher" placeholder="Editeur" value="<?= $publisher?>" required>
                        <input type="date" placeholder="Année de publication" value="<?= $publication_year?>"  name="publication_year">
                        <input type="text" id="statue" name="category" value="<?= $category ?>" placeholder="Catégorie" required>
                        <input type="number" placeholder="stock" value="<?= $stock ?>" name="stock">
                        <textarea name="summary" placeholder="Résumé" rows="5" cols="40"><?= $summary ?></textarea>
                        <textarea name="img" placeholder="lien vers l'image" rows="5" cols="40"><?= $img ?></textarea>
                        <input  id="sub" type="submit" name="modifLivre" value="Modifier">
                        <!-- <input  id="sup" type="submit" name="suppLivre" value="Supprimer"> -->
                        <button id="sup" type="submit" name="suppLivre">Supprimer</button>
                    </form>
                </div>
    </div>
   
    
</body>

</html>