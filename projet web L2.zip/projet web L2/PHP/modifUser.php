<?php
/**
 * Modifie les données d'un utilisateur par l'admin
 */
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['admi_email'] sont bien definie
   if(!(isset($_SESSION['id_admin']) && isset($_SESSION['first_name_admin']))) {
        header("Location: connexion.php");
        exit();
    }
    if(isset($_GET['id']) && !empty($_GET['id'])){
        // Cette fonction renvoie une valeur valide sans modifier la chaîne d'origine.
        function validate($data){
            $trimmed_data = trim($data); // "trim()" supprime les espaces vides au début et à la fin de la chaîne.
            $stripped_data = stripslashes($trimmed_data); // Supprime les barres obliques inverses ("") de la chaîne (évite les failles de sécurité).
            $html_encoded_data = htmlspecialchars($stripped_data); // Convertit les caractères spéciaux en entités HTML (évite les injections de code dans le formulaire).
            return $html_encoded_data; // Retourne la chaîne de caractères validée.
        }
        $id = $_GET['id']; 
        if(isset($_POST['suppUtilisateur'])){
            try {
                $dsn = "mysql:host=localhost;dbname=projet_webl2";
                $connexion = new PDO($dsn, "root", "");
                $requete1 = "DELETE FROM users WHERE user_id = '$id';";         
                $connexion->query($requete1);
                header("Location: displayUser.php?succes= Suppression réaliser avec succes!"); 
                exit();
            }catch(PDOException $e) {
                exit('Erreur : '.$e->getMessage());
            }   
        }else{
            try {
            $dsn = "mysql:host=localhost;dbname=projet_webl2";
            $connexion = new PDO($dsn, "root", "");
            $recup = $connexion->query("SELECT * FROM users WHERE user_id = '$id';");
            $resultat = $recup->fetch();
            }catch(PDOException $e) {
                exit('Erreur : '.$e->getMessage());
            } 
            $first_name = $resultat['first_name'];
            $last_name = $resultat['last_name'];
            $birth_date = $resultat['birth_date'];
            $email = $resultat['email'];
            $statue = $resultat['statue'];

            if (empty($first_name) || empty($last_name) || empty($birth_date) 
                || empty($email) || empty($statue) ){
                header("Location: modifUser.php?error= Veuillez remplir tous les champs, s'il vous plaît."); 
                exit();
            }

            if (isset($_POST["first_name"]) && isset($_POST['last_name']) && isset($_POST['birth_date']) 
                && isset($_POST['email']) && isset($_POST['statue']) ){
                $first_name_saisie = validate($_POST['first_name']);
                $last_name_saisie = validate($_POST['last_name']);
                $birth_date_saisie = $_POST['birth_date'];
                $email_saisie = validate($_POST['email']);
                if (isset($_POST['pwd']) && !empty($_POST['pwd'])){
                    $password_saisie = password_hash($_POST['pwd'], PASSWORD_DEFAULT);
                }
                $statue_saisie = $_POST['statue'];
                $choix = $_POST['modifUser'];
                if($choix == 'Modifier'){
                    try {
                        if (isset($_POST['pwd']) && !empty($_POST['pwd'])){
                            $req = "UPDATE users SET first_name = :first_name, 
                            last_name = :last_name , 
                            birth_date = :birth_date ,
                            email = :email , password = :password , 
                            statue = :statue WHERE user_id = :id;";  
                            $connexion->prepare($req)->execute(array(
                                ':first_name' => $first_name_saisie,
                                ':last_name' => $last_name_saisie,
                                ':birth_date' => $birth_date_saisie,
                                ':email' => $email_saisie,
                                ':password' => $password_saisie,
                                ':statue' => $statue_saisie,
                                ':id' => $id
                            ));
                        }else{
                            $req = "UPDATE users SET first_name = :first_name, 
                            last_name = :last_name , 
                            birth_date = :birth_date ,
                            email = :email , 
                            statue = :statue WHERE user_id = :id;";  
                            $connexion->prepare($req)->execute(array(
                                ':first_name' => $first_name_saisie,
                                ':last_name' => $last_name_saisie,
                                ':birth_date' => $birth_date_saisie,
                                ':email' => $email_saisie,
                                ':statue' => $statue_saisie,
                                ':id' => $id
                            ));
                        }
                        header("Location: displayUser.php?succes= Modification réaliser avec succes!"); 
                        exit();
                    }catch(PDOException $e) {
                        exit('Erreur : '.$e->getMessage());
                    }   
                }
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Ajout de livres</title>
  <link rel="stylesheet" href="../CSS/addUser.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&family=Roboto:wght@100;300;400;500;700;900&display=swap"
    rel="stylesheet" />
    <link rel="shortcut icon" href="../Image/logo.svg" type="image/x-icon">
</head>

<body>

    <div class="global-container">

        <nav class="side-nav">
            <div class="nav-logo">
                <img src="../Image/logo.svg">
                <h1>Admin</h1>
            </div>

            <a href="addUser.php" class="bloc-link">
                <img src="../Image/dashboard.svg">
                <span class="nav-links">Ajout</span>
            </a>
            <a href="displayUser.php" class="bloc-link">
                <img src="../Image/profil.png">
                <span class="nav-links">utilisateur</span>
            </a>
            <a href="adminHome.php" class="bloc-link active">
            <img src="../Image/pile-de-livres.png">
                <span class="nav-links">Modification livre</span>
            </a>
            <a href="displayEnpreint.php" class="bloc-link">
                <img src="../Image/calendar.svg">
                <span class="nav-links">Livres Empruntés</span>
            </a>
        </nav>
   
    </div>
    <div class="btn">
        <a href="displayUser.php" class="btn-inscription1">Retour a l'affichage des utilisateurs</a>
    </div>
    <div class="form">
                <div class="container">
                    <form action="" method="POST">
                        <h1 id="h1">MODIFICATION UTILISATEUR</h1>
                        <!--Methode get pour pouvoire chercher le message d'erreur dans l'url et l'afficher au dessus du formulaire en cas d'erreur-->
                        <?php if(isset($_GET['error'])){?>
                            <p id="error"><?php echo $_GET['error'] ?></p>
                        <?php }?>
                        <input type="text" id="first_name" name="first_name" placeholder="Nom" value="<?= $first_name ?>" required>
                        <input type="text" id="last_name" name="last_name" placeholder="Prenom" value="<?= $last_name ?>" required></br>
                        <input type="date" id="birth_date" placeholder="date" value="<?= $birth_date ?>" name="birth_date">
                        <input type="email" name="email" value="<?= $email ?>" placeholder="Email">
                        <input type="password" name="pwd" placeholder="Ne pas remplir pour garder le même mot de passe."></br>
                        <select id="section" name="statue">
                            <?php if($statue === "admin"){?>
                                <option value="admin">ADMIN</option>
                                <option value="utilisateur">UTILISATEUR</option>
                                <option value="premium">PREMIUM</option>
                            <?php }elseif($statue === "utilisateur"){ ?>
                                <option value="utilisateur">UTILISATEUR</option>
                                <option value="admin">ADMIN</option>
                                <option value="premium">PREMIUM</option>
                            <?php }elseif($statue === "premium"){?>
                                <option value="premium">PREMIUM</option>
                                <option value="utilisateur">UTILISATEUR</option>
                                <option value="admin">ADMIN</option>
                            <?php }?>
                        </select>
                        <input  id="sub" type="submit" name="modifUser" value="Modifier">
                        <button id="sup" type="submit" name="suppUtilisateur">Supprimer</button>
                    </form>
                </div>
    </div>
   
    
</body>

</html>