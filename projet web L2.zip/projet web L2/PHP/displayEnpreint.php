<?php
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['first_name'] sont bien definie
   if(!(isset($_SESSION['id_admin']) && isset($_SESSION['first_name_admin']))) {
        header("Location: connexion.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Liste de livre enpreint</title>
  <link rel="stylesheet" href="../CSS/styleAdminHome.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&family=Roboto:wght@100;300;400;500;700;900&display=swap"
    rel="stylesheet" />
    <link rel="shortcut icon" href="../Image/logo.svg" type="image/x-icon">
<script src="../JS/displayDynamiqueEnpreint.js" defer></script>

</head>

<body>

  <div class="global-container">

    <nav class="side-nav">
      <div class="nav-logo">
        <img src="../Image/logo.svg">
        <h1>Admin</h1>
      </div>
      <a href="addUser.php" class="bloc-link">
          <img src="../Image/dashboard.svg">
          <span class="nav-links">Ajout</span>
      </a>
      <a href="displayUser.php" class="bloc-link">
          <img src="../Image/profil.png">
          <span class="nav-links">utilisateurs</span>
      </a>
      <a href="adminHome.php" class="bloc-link ">
          <img src="../Image/pile-de-livres.png">
          <span class="nav-links">Livres</span>
      </a>
      <a href="displayEnpreint.php" class="bloc-link active">
          <img src="../Image/calendar.svg">
          <span class="nav-links">Livres Empruntés</span>
      </a>
    </nav>

    <main class="main-content">
    <div class="container-flex">
        <div class="input-control">
            <label for="search">
            <img src="../Image/search.svg">
            </label>
            <input type="text" id="search" placeholder="Recherche">
        </div>
        <h2 class="bv"><?php echo "Admin <span id=\"namecolor\">".$_SESSION['first_name_admin']." ".$_SESSION['last_name_admin']; ?></span></h2>
        <button type="button" id="deco"><a href="deconnexion.php">Déconnexion</a></button>
    </div>
      <h2 class="main-title">Livres Enpreinté</h2>
      <table class="table">
        <tr>
          <th>Nom du livre</th>
          <th>Nom de l'utilisateur</th>
          <th>Prenom de l'utilisateur</th>
          <th>Date de debut</th>
          <th>Date de fin</th>
          <th>Quantité</th>
          <th>Image</th>
        </tr>
      </table>

    </main>

  </div>
</body>

</html>