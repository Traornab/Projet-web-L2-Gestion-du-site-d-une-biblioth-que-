<?php
/**
 * Renouvelle la date d'enpreint 1 semaine pour un utilisateur normale et 1 mois pour un utilisateur premium
 */
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['first_name'] sont bien definie
   if(!(isset($_SESSION['id_user']) && isset($_SESSION['first_name_user']))) {
        header("Location: connexion.php");
        exit();
    }
    $loan_id = $_GET['loan_id'];
    $date = new DateTime($_GET['date']);
    // Vérifier le statut de l'utilisateur et modifier la date en conséquence
    if ($_SESSION['statue_user'] === "utilisateur") {
        $date->modify('+2 weeks'); // Ajouter 2 semaines
    } elseif ($_SESSION['statue_user'] === "premium") {
        $date->modify('+1 month'); // Ajouter 1 mois
    }   
    // Formatter la date selon le format désiré
    $dateFormatted = $date->format('Y-m-d');
    try {
        $dsn = "mysql:host=localhost;dbname=projet_webl2";
        $connexion = new PDO($dsn, "root", "");
        $requete1 = "UPDATE loan SET end_date = '$dateFormatted' WHERE loan_id = $loan_id;";         
        $connexion->query($requete1);
        header("Location: displayEnpreintUser.php?succes= Votre livre a été renouveler avec secces!"); 
        exit();
    }catch(PDOException $e) {
        exit('Erreur : '.$e->getMessage());
    }
?>