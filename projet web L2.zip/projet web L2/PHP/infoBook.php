<?php
/**
 * Affiche les information sur un livre
 */
session_start();
   //Verification si $_SESSION['id'] et $_SESSION['first_name'] sont bien definie
   if(!(isset($_SESSION['id_user']) && isset($_SESSION['first_name_user']))) {
    header("Location: connexion.php");
        exit();
    }
    if (isset($_GET['id'])){
        $id = $_GET['id'];
        try {
            $dsn = "mysql:host=localhost;dbname=projet_webl2";
            $connexion = new PDO($dsn, "root", "");
            $recup = $connexion->query("SELECT * FROM book WHERE id = '$id';");
            $resultat = $recup->fetch();
            $title = $resultat['title'];
            $author = $resultat['author'];
            $publisher = $resultat['publisher'];
            $publication_year = $resultat['publication_year'];
            $category = $resultat['category'];
            $stock = $resultat['stock'];
            $summary = $resultat['Summary'];
            $img = $resultat['img'];
        }catch(PDOException $e) {
            exit('Erreur : '.$e->getMessage());
        } 
        $_SESSION['tmp'] = $id;

    }
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Information</title>
  <link rel="stylesheet" href="../CSS/styleUserHome.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&family=Roboto:wght@100;300;400;500;700;900&display=swap"
    rel="stylesheet" />
    <link rel="shortcut icon" href="../Image/logo.svg" type="image/x-icon">

</head>

<body>

  <div class="global-container">

    <nav class="side-nav">
      <div class="nav-logo">
        <img src="../Image/logo.svg">
        <h1><?php echo "<span id=\"namecolor\">".$_SESSION['first_name_user']." ".$_SESSION['last_name_user']; ?></span></h1>
      </div>

      <a href="userHome.php" class="bloc-link">
        <img src="../Image/home.png">
        <span class="nav-links">Acceuil</span>
      </a>
      <a href="panier.php" class="bloc-link">
        <img src="../Image/shopping-online.png">
        <span class="nav-links">Panier</span>
      </a>
      <a href="displayEnpreintUser.php" class="bloc-link">
        <img src="../Image/pile-de-livres.png">
        <span class="nav-links">Livre Enpreinté</span>
      </a>
      <a href="" class="bloc-link active">
        <img src="../Image/info.png">
        <span class="nav-links">Information</span>
      </a>
    </nav>

    <main class="main-content">
        <div class="container-flex">
            <h2 class="bv"><?php echo "Utilisateur <span id=\"namecolor\">".$_SESSION['first_name_user']." ".$_SESSION['last_name_user']; ?></span></h2>
            <button type="button" id="deco"><a href="userHome.php">Retour</a></button>
        </div><br/>
        
        <h2 class="main-title">Information sur le livre <span id="namecolor">"<?= $title?>"</span></h2>
        <div class="book-container">
            <img class="book-image" src="<?=$img?>" alt="Image du livre sélectionnée">
            <div class="book-info">
                <h2 class="book-title"><?=$title?></h2>
                <p class="book-summary"><?=$summary?></p>
                <div class="book-details">
                    <p><strong>Auteur:</strong> <?=$author?></p>
                    <p><strong>Éditeur:</strong> <?=$publisher?></p>
                    <p><strong>Année de publication:</strong> <?=$publication_year?></p>
                    <p><strong>Catégorie:</strong> <?=$category?></p>
                    
                <?php  
                if ($stock <= 0){
                    echo "<p style=\"color:red\">Rupture de stock</p>";
                }
                else{
                  ?>
                  <p><strong>Stock restant:</strong> <?=$stock?></p>
                </div>
                <form action="ajoutPanier.php" method="post">
                    <input type="submit" id="ajout-panier"  class="add-to-cart" name="ajoutPanier" value="Ajouter au panier">
                </form>
                <?php
                }
                ?>
            </div>
        </div>
    </main>
  </div>
</body>

</html>