<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page de connexion</title>
    <!-- <link rel="stylesheet" href="../CSS/styleAccueil.css"> -->
    <link rel="stylesheet" href="../CSS/style_connexion.css">
    <link rel="shortcut icon" href="../Image/logo.svg" type="image/x-icon">
    <script src="../JS/script.js" defer></script>
</head>
<body>
    <header>
        <a href="../HTML/index.html" class="logo"><img src="../Image/logo.svg" alt="logo"> <span>R</span>eadEase</a>
        <div class="dispmenu" onclick="displayMenu();">
            <ul class="navbar">
                <li> <a href="../HTML/index.html" onclick="displayMenu();">Accueil</a></li>
                <li> <a href="../HTML/index.html #banniere" onclick="displayMenu();">A propos</a></li>
                <li> <a href="../HTML/index.html #derni" onclick="displayMenu();">Dernière sorties</a></li>
                <li> <a href="../HTML/index.html #reco" onclick="displayMenu();">Recomandé</a></li>
                <li> <a href="../HTML/index.html #footer" onclick="displayMenu();">Contact</a></li>
                <a href="connexion.php" class="btn-connexion" onclick="displayMenu();">Connexion</a>
            </ul>
        </div>
    </header>
    <main>
    <div class="form">
                <div class="container">
                    <form action="gestionconnexion.php" method="POST">
                        <h1 id="h1">CONNEXION</h1>

                        <!--Methode get pour pouvoire chercher le message d'erreur dans l'url et l'afficher au dessus du formulaire en cas d'erreur-->
                        <?php if(isset($_GET['error'])){?>
                            <p id="error"><?php echo $_GET['error'] ?></p>
                        <?php }?>
                        <!--Formulaire pour connexion de l'administrateur-->
                        <input type="email" name="email" placeholder="Email"><br>
                        <input type="password" name="pwd" placeholder="Mot de passe"><br>
                        <input  id="sub" type="submit" name="connexion" value="Se connecter">
                    </form>
                    
                    <!-- OMBRES-->
                    <div class="drop drop-1"></div>
                    <div class="drop drop-2"></div>
                    <div class="drop drop-3"></div>
                </div>
    </div>
    </main>
</body>
</html>