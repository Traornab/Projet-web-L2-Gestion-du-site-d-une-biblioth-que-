<?php
    session_start();
    if(isset($_POST["email"]) && isset($_POST["pwd"])){
        //cette fonction renvoie une valeur valide
        function validate($data){
            $data = trim($data);// "trim()" supprime les espaces vides au début et à la fin de la chaîne.
            $data = stripslashes($data);//supprime les barres obliques inverses ("") de la chaîne (eviter des failles de securiter)
            $data = htmlspecialchars($data);//convertit les caractères spéciaux en entités HTML (eviter les injection de code dans le formulaire)
            return $data;
        }
        $email= validate($_POST["email"]);
        $password = validate($_POST["pwd"]);
            try {
                $dsn = "mysql:host=localhost;dbname=projet_webl2";
                $connexion = new PDO($dsn, "root", "");
                
            }catch(PDOException $e) {
            exit('Erreur : '.$e->getMessage());
            } 
    
            if(empty($email)) {
                header("Location: connexion.php?error= l'email est requis"); 
                exit();
            }else if(empty($password)) {
                header("Location: connexion.php?error= le mot de passe est requis");
                exit();
            }else{
                $requete = " SELECT * FROM users WHERE email = '$email'";
                $res = $connexion->query($requete);
                if($res->rowCount() === 1) {
                    $row = $res->fetch(PDO::FETCH_ASSOC);
                    if($row['email'] == $email && password_verify($password, $row['password'])){
                        if ($row['statue'] === "admin"){
                            $_SESSION['id_admin'] = $row['user_id'];
                            $_SESSION['first_name_admin'] = $row['first_name'];
                            $_SESSION['last_name_admin'] = $row['last_name'];
                            $_SESSION['statue_admin'] = $row['statue'];
                           header("Location: adminHome.php");
                        }else {
                            $_SESSION['id_user'] = $row['user_id'];
                            $_SESSION['first_name_user'] = $row['first_name'];
                            $_SESSION['last_name_user'] = $row['last_name'];
                            $_SESSION['statue_user'] = $row['statue'];
                            $_SESSION['panier'] = [];
                            header("Location: userHome.php");
                        }
                        exit();
                    }else{
                        header("Location: connexion.php?error= E-mail ou mot de passe incorrect");
                        exit();
                    }
        
                }else{
                    header("Location: connexion.php?error= E-mail ou mot de passe incorrect");
                    exit();
                }
            }
        
    }else{
        //sinon nous revoie sur la page de connexion
        header("Location: connexion.php");
        exit();
    }
?>