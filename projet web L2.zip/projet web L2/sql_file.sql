CREATE DATABASE projet_webl2;

use projet_webl2;

-- Création de la table "users" pour les utilisateurs
CREATE TABLE users (
    user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    birth_date DATE,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(100) UNIQUE NOT NULL,
    statue VARCHAR(50) NOT NULL
) ENGINE = INNODB;

-- Création de la table "book" pour les livres
CREATE TABLE book (
    id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    publisher VARCHAR(255),
    publication_year DATE,
    category VARCHAR(50),
    stock INT NOT NULL,
    Summary longtext NOT NULL,
    img longtext NOT NULL
) ENGINE = InnoDB;

-- Création de la table "loan" pour les emprunts
CREATE TABLE loan (
    loan_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    user_id INT UNSIGNED,
    start_date DATE,
    end_date DATE,
    qte INT UNSIGNED,
    FOREIGN KEY (book_id) REFERENCES book (id),
    FOREIGN KEY (user_id) REFERENCES users (user_id)
) ENGINE = INNODB;

-- Pour cette insertion les mots de passes sont le prenom de l'utilisateur suivie de .com (naby.com pour 1)

INSERT INTO
    `users` (
        `user_id`,
        `first_name`,
        `last_name`,
        `birth_date`,
        `email`,
        `password`,
        `statue`
    )
VALUES (
        1,
        'Savané',
        'Naby',
        '2004-08-04',
        'naby@gmail.com',
        '$2y$10$OqOAWiSf2Nii04QyO/1ZPOThxfUUGKb0/m9f6qZlLYMvmzHbbB99O',
        'admin'
    ),
    (
        2,
        'Dupont',
        'Jean',
        '2000-01-12',
        'jean@hotmail.fr',
        '$2y$10$yPYvIoIx9WYKMOFmB4TqPeX7ibNTag6iQSHvuBb06Lzllsc7rj8xi',
        'utilisateur'
    );

INSERT INTO
    `book` (
        `id`,
        `title`,
        `author`,
        `publisher`,
        `publication_year`,
        `category`,
        `stock`,
        `Summary`,
        `img`
    )
VALUES (
        1,
        'Toto courtes',
        '100blagues.fr,',
        'Lemaitre Publishing',
        '2015-08-25',
        'Humor',
        6,
        'Les plus courtes sont les meilleures ! Maman reçoit une amie. Quand arrive Toto dans le salon, celle-ci demande : - Tiens donc, Toto, je ne t’avais pas déjà croisé quelque part ? - Je ne pense pas, madame, répond Toto, je n’y suis encore jamais allé ! Les meilleures blagues de Toto pour votre plus grand plaisir ! Véritable concentré de bonne humeur qui ravira grands et petits. (Re)découvrez des centaines de blagues grâce à la collection 100blagues.fr ! Des incontournables aux plus farfelues, il y en aura pour tous les goûts ! Un moment de rigolade à partager aussi bien en famille qu\'entre amis. Dans la collection 100blagues.fr : • Toto pour enfants • Toto à la maison • Toto cochonnes • 100 blagues • 100 histoires drôles • 500 blagues de Toto et histoires drôles',
        'http://books.google.com/books/content?id=rOhxCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        2,
        'Toto cochonnes',
        '100blagues.fr,',
        'Lemaitre Publishing',
        '2015-08-25',
        'Humor',
        1,
        'Envie d\'un moment détente ? L\'indémodable Toto n\'attend que vous ! Un matin, la maman de Toto arrive embêtée au travail : - Monsieur le Directeur, j’ai quelque chose à vous annoncer. Une bonne, et une mauvaise nouvelle. - Je vous écoute ! - Vous n’êtes pas stérile ! Les meilleures blagues de Toto pour votre plus grand plaisir ! Véritable concentré de bonne humeur qui ravira grands et petits. (Re)découvrez des centaines de blagues grâce à la collection 100blagues.fr ! Des incontournables aux plus farfelues, il y en aura pour tous les goûts ! Un moment de rigolade à partager aussi bien en famille qu\'entre amis. Dans la collection 100blagues.fr : • Toto pour enfants • Toto à la maison • Toto courtes • 100 histoires drôles • 100 blagues • 500 blagues de Toto et histoires drôles',
        'http://books.google.com/books/content?id=0ehxCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        3,
        'Toto pour enfants',
        '100blagues.fr,',
        'Lemaitre Publishing',
        '2015-08-25',
        'Humor',
        0,
        'Envie d\'un moment détente ? L\'indémodable Toto n\'attend que vous ! Après un contrôle de mathématiques, Toto et son ami estiment leur résultat. - Je pense que j’ai complètement raté, dit Toto, la mine dépitée. Je m’attends à avoir un 0. Son ami tente de le réconforter. - Mais tu es sûr, Toto ? Tu avais pourtant bien révisé ? - Oh oui, j’en suis sûr, aussi sûr que 3 et 4 font 10... Les meilleures blagues de Toto pour votre plus grand plaisir ! Véritable concentré de bonne humeur qui ravira grands et petits. (Re)découvrez des centaines de blagues grâce à la collection 100blagues.fr ! Des incontournables aux plus farfelues, il y en aura pour tous les goûts ! Un moment de rigolade à partager aussi bien en famille qu\'entre amis. Dans la collection 100blagues.fr : • Toto à l\'école • Toto à la maison • Toto courtes • Toto cochonnes • 100 blagues • 500 blagues de Toto et histoires drôles',
        'http://books.google.com/books/content?id=PehxCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        4,
        'Toto à la maison',
        '100blagues.fr,',
        'Lemaitre Publishing',
        '2015-08-25',
        'Humor',
        5,
        'Envie d\'un moment détente ? L\'indémodable Toto n\'attend que vous ! Après l’école, Toto vient poser quelques questions à Maman sur sa leçon de politique qu’il n’a pas très bien comprise. - Maman, est-ce que tu pourrais m’expliquer ce qu’est un gouvernement ? - Pour te donner une image afin que tu comprennes mieux, on peut dire que Papa représente le gouvernement et la maison le pays : il est le chef de la maison. - Et l’économie ? - On peut dire que l’économie, c’est comment tu gères l’argent de poche que Papa te donne. - Super, Maman ! Eh bien, est-ce que tu pourrais dire au gouvernement que l’économie rencontre quelques difficultés en ce moment ? Les meilleures blagues de Toto pour votre plus grand plaisir ! Véritable concentré de bonne humeur qui ravira grands et petits. (Re)découvrez des centaines de blagues grâce à la collection 100blagues.fr ! Des incontournables aux plus farfelues, il y en aura pour tous les goûts ! Un moment de rigolade à partager aussi bien en famille qu\'entre amis. Dans la collection 100blagues.fr : • Toto pour enfants • Toto courtes • Toto cochonnes • 100 blagues • 500 blagues de Toto et histoires drôles',
        'http://books.google.com/books/content?id=G-lxCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        5,
        '800 blagues de Toto 2022',
        'Collectif',
        'Deux Coqs d\'Or',
        '2021-10-13',
        'Juvenile Fiction',
        2,
        'Pour une année 2022 pleine d\'histoires drôles, retrouvez l\'incontournable millésime des 800 blagues de Toto ! À partager avec ses amis ou sa famille pour de grands fous rires ! Retrouvez le roi de la farce à l\'école, en vacances, avec ses parents ou ses copains. Avec des BD !',
        'http://books.google.com/books/content?id=3nlfEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        6,
        'Toto à l\'école',
        '100blagues.fr,',
        'Lemaitre Publishing',
        '2015-08-25',
        'Humor',
        10,
        'Envie d\'un moment détente ? L\'indémodable Toto n\'attend que vous ! En classe, la maîtresse propose un problème de calcul : - Si je vais au marché, et que j’achète quatre bouteilles de vin, valant 3 € chacune, combien cela me fait ? Toto répond : - Je ne sais pas pour vous, madame, mais à la maison, ça fait généralement deux jours en comptant l’apéro ! Les meilleures blagues de Toto pour votre plus grand plaisir ! Véritable concentré de bonne humeur qui ravira grands et petits. (Re)découvrez des centaines de blagues grâce à la collection 100blagues.fr ! Des incontournables aux plus farfelues, il y en aura pour tous les goûts ! Un moment de rigolade à partager aussi bien en famille qu\'entre amis. Dans la collection 100blagues.fr : • Toto pour enfants • Toto à la maison • Toto courtes • Toto cochonnes • 100 blagues • 500 blagues de Toto et histoires drôles',
        'http://books.google.com/books/content?id=QOlxCgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        7,
        '800 blagues préférées de Toto 2017',
        'Collectif',
        'Deux Coqs d\'Or',
        '2016-09-28',
        'Juvenile Nonfiction',
        1,
        'Et celle-là, tu la connais ? 800 blagues de Toto, à partager avec ses amis ou sa famille pour de grands fous rires !',
        'http://books.google.com/books/content?id=X7mcDQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        8,
        '800 blagues de Toto 2020',
        'Collectif',
        'Deux Coqs d\'Or',
        '2019-09-25',
        'Juvenile Fiction',
        3,
        'Et celle-là, tu la connais ? 800 blagues et devinettes de Toto, à partager avec ses amis ou sa famille pour de grands fous rires ! Retrouve le roi de la farce à l\'école, en vacances, avec ses parents ou ses copains. Avec des BD et des petits jeux !',
        'http://books.google.com/books/content?id=yqbMDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        9,
        'Les Zistoires de Toto avec un grand Z',
        'Laurent GAULET',
        'First',
        '2014-08-28',
        'Fiction',
        3,
        'Incroyable mais vrai ! Incroyable mais vrai ! On a retrouvé le cahier authentique des histoires de Toto ! Découvrez les véritables blagues de ce petit écolier hors du commun et sacrément coquin ! Au milieu des taches d\'encre de plumier, des boulettes de papier et des lignes d\'écriture raturées, ce cahier d\'écolier vous offrira une bonne tranche de rire avec les VRAIES histoires et blagues de Toto. Avec, en cadeau, un super emploi du temps Toto à accrocher au mur et à compléter ! Toto rentre de l\'école et annonce fièrement à son papa : - Aujourd\'hui, j\'ai très bien répondu à la question de la maîtresse ! - Ah ? s\'étonne le père. Et quelle était la question ? - Elle a demandé \" Qui a mis cette punaise sur ma chaise ?\", et j\'ai répondu : \"C\'est moi !\"',
        'http://books.google.com/books/content?id=e3NSBAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        10,
        'Le Château à Toto, opéra-bouffe en trois actes',
        'Henri Meilhac, Ludovic Halévy',
        'Inconnu',
        '0000-00-00',
        'Inconnue',
        2,
        'Aucun résumé disponible',
        'http://books.google.com/books/content?id=ljJdAAAAcAAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        11,
        'L\'argot du foot',
        'Pierre Merle',
        'Baudoin-Mona',
        '0000-00-00',
        'French language',
        1,
        'Aucun résumé disponible',
        'http://books.google.com/books/content?id=eH8TAQAAIAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api'
    ),
    (
        12,
        'Mon année foot',
        'Pierre Ménès',
        'Editions du Rocher',
        '2011-06-30',
        'Social Science',
        2,
        'Après le succès de Carton rouge pour les Bleus, bilan d\'un rêve gâché et brisé en Afrique du Sud, Pierre Ménès revient sur son terrain de jeu favori : celui du foot dans tous ses états. De ses textes au ton très personnel, édités quotidiennement sur son blog Pierrot le Foot\", nous avons constitué la chronique d\'une saison. Découvrir ou relire un feuilleton écrit au jour le jour donne une saveur toute particulière à ce livre, le premier d\'une série de rendez-vous annuels, clôturant la saison de foot. L\'auteur y montre son flair, ses coups de coeur et de gueule, ses inquiétudes, mais aussi ses erreurs. Le chroniqueur vedette du \"Canal football club\" sur Canal + y apparaît avec son humour acide habituel. Ce livre, devrait, au fil des années, devenir le rendez-vous attendu des amoureux du parler vrai dans le football.\"',
        'http://books.google.com/books/content?id=lkAPDQAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        13,
        'Sous les crampons... la plage',
        'Daniel COHN-BENDIT, Patrick LEMOINE',
        'Robert Laffont',
        '2018-04-05',
        'Social Science',
        2,
        '\" On aime toute sa vie ce dont on s\'est régalé enfant... \" ... et ce livre le prouve, où Dany Cohn-Bendit explore avec la verve, l\'enthousiasme, l\'emportement, parfois, qu\'on lui connaît, sa passion pour le football. Du jeune garçon émerveillé par le Brésil de 1958 (celui qui révéla au monde un génie nommé Pelé) à l\'homme qui pourfend le foot-business des dernières années tout en défendant contre vents et marées la conception d\'un jeu offensif, généreux, festif, on retraverse avec ces souvenirs plus de cinquante ans de notre mémoire collective. Et pas seulement footballistique, tant le foot est le reflet de la société, particulièrement quand c\'est Dany qui nous le raconte, chez qui le virus de la politique ne peut jamais être bien loin. À la veille d\'une nouvelle Coupe du monde (en Russie) qu\'il suivra avec la même gourmandise que les précédentes, Daniel Cohn-Bendit célèbre ici à sa manière le cinquantième anniversaire de Mai 68, dans un de ces contre-pieds réjouissants et \" provocs \" dont il a le secret.',
        'http://books.google.com/books/content?id=5qBPDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        14,
        'Main basse sur l\'argent du foot français',
        'Christophe Bouchet',
        'Robert Laffont',
        '2023-10-12',
        'Sports & Recreation',
        2,
        'C\'est le coup du siècle... En mai 2022, un fonds étranger est devenu actionnaire de la Ligue. En cadeau de bienvenue, il aligne 1,5 milliard d\'euros. Dans la foulée, le président de la Ligue – l\'acteur présumé de ce deal –, Vincent Labrune, perçoit un bonus de 3 millions d\'euros, et le triplement de son salaire. La Ligue, moribonde quelques mois plus tôt, mène grand train. Augmentations à gogo, promesses de bonus vertigineux, un siège acheté et rénové à prix d\'or... Ruinés par le dossier Mediapro et le Covid, les présidents de clubs ont sacrifié les intérêts de leurs clubs au profit de la finance pour une durée illimitée. Ces indices persuadent l\'auteur de mener l\'enquête: comment certains clubs ont-ils pu accepter ce contrat? Qui a choisi ce fonds? Qui a mis la pression sur les députés pour voter dans la précipitation l\'obligatoire changement de loi autorisant ce type d\'affaire? Les clubs vont le payer cher et même, pour certains, très cher. Dans ce cas, pourquoi les pouvoirs publics ont-ils laissé faire? Mensonges, coups tordus, paris fous...: cette enquête haletante nous emmène dans les coulisses de la Ligue et des clubs, des chaînes de télévision et du pouvoir, et met au jour le péril imminent auquel s\'expose le foot français.',
        'http://books.google.com/books/content?id=8STcEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        15,
        'L\'anti-guide du foot',
        'Guillaume Evin',
        'Dunod',
        '2018-04-04',
        'Art',
        1,
        'La France est le pays du football, il fait partie de sa culture. Les libraires débordent ainsi de livres sur le football. La quasi-totalité d’entre eux sont des biographies ou des témoignages de joueurs célèbres ou d\'entraineurs emblématiques, on trouve aussi des beaux-livres sur les matchs cultes. Mais aucun de ces livres ne vous dira pourquoi les cages de foot ont des dimensions si bizarres, ce qui se passe dans la tête d\'un joueur lorsqu\'il fait une tête, ou si la mi-temps sert vraiment à aller aux toilettes! En torpillant les idées reçues, cet anti-guide vous fait découvrir le football d’une façon nouvelle et ludique, à travers des questions que vous n’imaginiez pas pouvoir vous poser un jour.',
        'http://books.google.com/books/content?id=Q9VTDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        16,
        'Mon Carnet Du Foot',
        'François ChukwuEmeka',
        'BoD – Books on Demand',
        '2023-02-24',
        'Sports & Recreation',
        1,
        '« La réussite est planifiable, sauf la fin et les résultats resteront ouverts. » C est avec cette citation de Jogi Löw, ancien entraîneur de l équipe nationale de football de l Allemagne, suivi dans une interview de la radio d information, dans le temps appelé B5-Nachrichten, aujourd hui renominée BR-24, que François ChukwuEmeka s est vu confirmé dans son ambition de donner des astuces importantes à travers un autre prisme, pour permettre aux jeunes footballeuses, footballeurs et à leurs parents, de comprendre le football moderne. Il le fait à travers les histoires authentiques qu il a pu vivre au sein des deux associations sportives dont il est membre actif, le FC Unterföhring et la Communauté Sportive de Munich.',
        'http://books.google.com/books/content?id=yBywEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        17,
        'Parlons foot autrement !',
        'Philippe Sibut',
        'BoD - Books on Demand',
        '2020-12-17',
        'Sports & Recreation',
        1,
        'Voilà près de cinquante ans que la formation des sports collectifs, en particulier du football, se gangrène d\'illusions, de méprises et d\'absurdités. La psychologie cognitive, incomprise et dévoyée, s\'enracine chaque jour un peu plus sur nos belles pelouses vertes. Les éducateurs s\'empêtrent dans son conformisme, tombent dans ses impasses et entraînent avec eux les joueurs. Résultat ? On ne compte plus les jeunes qui, désenchantés, lassés de se prendre les pieds dans cette herbe folle, se détournent du football et abandonnent leurs espoirs. Ne nous y trompons pas, le neuro-cognitivisme a beaucoup apporté au sport. Mais il agonise aujourd\'hui de ses dérives et de ses propres travers. Si les sciences cognitives ont depuis longtemps tourné cette page, qu\'attendons-nous pour en faire de même sur le terrain ? A la lumière des avancées de la recherche contemporaine, cet essai réinterroge les construits culturels des sports collectifs afin de proposer de nouvelles pistes pédagogiques. Certains trouveront là de quoi conforter leur pratique empirique, tandis que d\'autres verront leurs certitudes bousculées. Tant mieux ! Peut-être leur créativité se libèrera-t-elle enfin ? Peut-être dépasseront-ils les chimères et les clichés ? Peut-être parviendront-ils à voir et à enseigner le foot, autrement ? Pour que nos enfants jouent le sourire au coeur, pour qu\'ils s\'élèvent sur leur propre chemin et pour que la passion les y guide durablement, le coach doit engager une véritable quête de sens. C\'est là tout l\'objet des défis parcourus dans ce livre.',
        'http://books.google.com/books/content?id=8KEPEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        18,
        'Optimiser SQL Server',
        'Rudi Bruchez',
        'Dunod',
        '2008-10-08',
        'Computers',
        1,
        'Cet ouvrage est destiné aux administrateurs de bases de données qui souhaitent améliorer les performances de leur base SQL Server. Le fonctionnement du moteur relationnel et celui du moteur de stockage sont abordés pour montrer comment maîtriser le fonctionnement interne de SQL Server. Les outils de supervision, d\'audit et de traçage sont présentés avec toutes les astuces et détails nécessaires à leur utilisation optimale. L\'ouvrage est conçu en deux parties : - La première porte sur le choix du matériel, la configuration du serveur, l\'organisation physique et logique des structures. Elle présente l\'architecture de SQL Server et les principes de l\'optimisation. - La seconde permet d\'écrire du code SQL plus performant et d\'optimiser ses requêtes en maîtrisant les mécanismes qui peuvent provoquer des attentes et de blocages.',
        'http://books.google.com/books/content?id=kLUlzTuLPBUC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        19,
        'SQL Server 2008',
        'Jérôme Gabillaud',
        'Editions ENI',
        '0000-00-00',
        'Database management',
        1,
        'Aucun résumé disponible',
        'http://books.google.com/books/content?id=Fgd63uHagk8C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        20,
        'SQL Server 2008 Express',
        'Jérôme Gabillaud',
        'Editions ENI',
        '0000-00-00',
        'Relational databases',
        1,
        'Aucun résumé disponible',
        'http://books.google.com/books/content?id=Bj7eC1n2E1AC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        21,
        'Génération After Foot',
        'Pierre Adrian, Bertrand Pirel',
        'Hugo Sport',
        '2021-05-12',
        'Sports & Recreation',
        1,
        'La véritable autobiographie de l\'After Foot ! Le 4 avril 2021, l\'After Foot fêtait ses quinze ans. Une éternité et une prouesse dans le monde de la radio, et des statistiques à donner le vertige : l\'émission la plus écoutée le soir, le podcast le plus téléchargé de FranceMais l\'After est beaucoup plus que cela. L\'After, c\'est du baume antidouleur pour les soirs de défaite. L\'After, c\'est une génération qui transmet à une autre sa culture du football, de la Nuit de Séville de 1982 au génie de Maradona. L\'After, ce sont des voix qui rassurent pendant la pandémie, quand tant d\'autres se sont tues. C\'est un repas de famille, attachant souvent, insupportable parfois. Sur la nappe, entre les plats, on a mis des micros et tout ce petit monde se retrouve, chahute, rigole, s\'énerve, bougonne. L\'After, surtout, c\'est une communauté. Celle de Romain, Joris,Mehdi, Najet, de tous ces habitués dont l\'émission fait partie du quotidien. Ils se couchent en l\'écoutant, ils font leur sport avec,ils partent au boulot, cuisinent ou voyagent branchés au podcast. L\'After les soigne, les console, les chagrine. Avec l\'After, il est enfin devenu possible d\'avoir une opinion sur le foot, de la partager, et peu importe que l\'on ait parfaitement tort ou totalement raison ; peu importe, aussi, qui l\'on est : comme le souligne Max du standard, « l\'After, c\'est la France. » Qu\'on soit chauffeur routier, taximan, employé de banque, éleveur de brebis, écrivain, comédien, ouvrier, expert comptable, chirurgien, footballeur de DH ou de première division, tout le monde écoute l\'After. Ce livre n\'est pas une enquête, encore moins une hagiographie. C\'est l\'exercice littéraire d\'un auditeur à l\'intention des autres auditeurs, en souhaitant qu\'ils y retrouvent les animateurs et les chroniqueurs comme de vieux copains. Qu\'ils découvrent l\'Italie de Daniel, l\'enfance provinciale de Gilbert et Florent, l\'histoire émouvante de Polo, la Madrid sensuelle de Fred Hermel. Qu\'ils revisitent certaines émissions emblématiques, des digressions fameuses. Avant de partir dans des discussions endiablées.',
        'http://books.google.com/books/content?id=xr2kEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        22,
        'SQL en concentré',
        'Kevin E. Kline',
        'O\'Reilly Media, Inc.',
        '2005-02-10',
        'Inconnue',
        4,
        'Développé dans les années 1970 à la suite des travaux d\'Edgar Codd, SQLI, (Structurel Query Language) est le langage par excellence d\'accès aux bases de données relationnelles. Il fait d\'ailleurs l\'objet l\'une norme ANSI/ISO. Tous les SGBDR implémentent SQL, mais les développeurs de chaque système ayant adapté le langage pour répondre à des besoins spécifiques, le passage d\'un dialecte à l\'autre est parfois délicat. Un ouvrage de référence s\'imposait donc. SQL en concentré réunit en un seul volume, tout ce qu\'il faut savoir sur le langage et ses différentes déclinaisons. Il commence par une introduction au modèle utilisé par les systèmes de gestion de bases de données relationnelles et une explication claire des concepts fondamentaux. Le coeur du livre reprend toutes les instructions de la dernière norme ANSI, à savoir SQL2003, et décrit les implémentations propres aux SGBDR majeurs : DB2, Oracle, MySQL, PostgreSQL et SQL Server, en indiquant la syntaxe et en donnant des exemples. Pour chaque commande, les auteurs partagent leur expérience et offrent des conseils de programmation. SQL ne se réduit pas à une série d\'instructions. Les types de données et la vaste bibliothèque de fonctions intégrées sont très importantes et s\'ils veulent travailler efficacement, les administrateurs le hases de données y ont forcément recours. Là aussi, le livre reprend fonction par fonction les caractéristiques générales, puis les variations liées à l\'implémentation. Un chapitre est également consacré à la programmation de bases de données à l\'aide de deux API fréquemment utilisées, ADO. NET et JDBC, qui fournissent une interface cohérente, partagée par tous les SGBDR. Cet ouvrage est destiné à différentes catégories d\'utilisateurs. Il sera utile aux programmeurs ayant besoin d\'un guide de référence SQL compact mais exhaustif. Il le sera également à ceux qui doivent passer d\'un dialecte de SQL à un autre. Enfin, il servira aux administrateurs de bases de données qui doivent exécuter des myriades d\'instructions SQL pour assurer la maintenance des bases de données de leur entreprise, pour créer et gérer des objets tels que les tables, les index et les vues.',
        'http://books.google.com/books/content?id=Ialyn2vbUUwC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        23,
        'SQL',
        'Nicolas Larrousse, Ryan Stephens, Ronald Plew, Arie Jones',
        'Inconnu',
        '2012-01-20',
        'Computers',
        1,
        'Ce livre, qui offre une initiation efficace et globale à la norme SQL (Structured Query Language), vous permettra de construire de puissantes bases de données relationnelles. Très pédagogique, il vous apprendra notamment à : • extraire, trier et regrouper les données • créer et gérer des objets dans un SGBD (système de gestion de bases de données) • définir les structures des données • sécuriser les actions par l\'utilisation de transactions • concevoir des requêtes élaborées • gérer les utilisateurs et améliorer les performances Cette édition prend en compte les évolutions récentes de la norme. Elle développe par ailleurs les différences de syntaxe entre les principaux SGBD (Oracle, SQL Server, MySQL). Parmi les autres nouveautés : • l\'utilisation des vues (SQL VIEW) • les opérateurs CUBE, ROLLUP et COALESCE • les types de données étendus : VAR BINARY, VARCHAR2, BLOB, TEXT, NUMERIC • les mécanismes de conversion détaillés : opérateur CAST et \"conversion implicite\" • l\'utilisation de SQL dans différents environnements, en particulier l’accès aux bases de données par le Web avec JDBC et OLE DB • les fonctions XML intégrées dans SQL Chaque chapitre s’achève sur une série d’exercices dont les corrigés sont disponibles sur le site compagnon. Ce dernier propose également des exercices supplémentaires, tous les codes sources, ainsi qu’un aide-mémoire des commandes SQL utilisées dans le livre. La démarche progressive et les exercices riches et variés font de ce livre un outil d’apprentissage indispensable pour les étudiants et les professionnels. Site compagnon disponible sur www.pearson.fr',
        'http://books.google.com/books/content?id=gxcSCwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        24,
        'SQL Server 2008',
        'William R. Stanek',
        'Microsoft Press',
        '2009-02-11',
        'Computers',
        1,
        'SQL Server 2008 est la nouvelle version du logiciel phare de Microsoft en matière de développement, d\'administration et de gestion des bases de données. Ce Guide de l\'Administrateur fournit toutes les informations concrètes pour administrer SQL Server 2008 le plus efficacement possible. Les principaux sujets traités sont l\'installation, la configuration et la personnalisation de SQL Server, l\'administration des serveurs, la création des comptes, l\'importation et l\'exportation des données, la mise en oeuvre de la réplication...',
        'http://books.google.com/books/content?id=PbnhSvM_urgC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        25,
        'SQL Server 2008',
        'Jérôme Gabillaud',
        'Editions ENI',
        '0000-00-00',
        'Database management',
        1,
        'Aucun résumé disponible',
        'http://books.google.com/books/content?id=Fgd63uHagk8C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        26,
        'Internet, le Web et les e-mails',
        'Véronique Campillo, Véronique Warion',
        'Pearson Education France',
        '0000-00-00',
        'Inconnue',
        5,
        'Aucun résumé disponible',
        'http://books.google.com/books/content?id=a5O-ukSiZPYC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        27,
        'Internet. Une infographie',
        'Tristan Mendès France, Quintin Leeds',
        'CNRS éditions',
        '2021-11-10',
        'Social Science',
        2,
        'Savez-vous d\'où vient le mot \" spam \" ? Vous doutiez-vous qu\'il y aura bientôt le wifi sur Mars ? Ou encore que le suédois est la troisième langue la plus fréquente sur Wikipédia ? Que le premier message électronique échangé entre deux ordinateurs a été envoyé en 1965 ? Ou enfin, que ce sont les Philippins qui passent le plus de temps sur les réseaux sociaux chaque jour ? Voilà donc ce que vous découvrirez en vous plongeant dans cette magnifique et foisonnante infographie. En une centaine de pages, cet ouvrage propose une nouvelle écriture graphique, aussi riche que ludique. Grâce à la datavisualisation, vous serez immergé dans l\'univers d\'Internet, à la rencontre de son histoire, de sa technologie, de ses acteurs, de ses dérives et de ses promesses. De la cartographie des câbles sous-marins à travers le monde à l\'inquiétante invasion des objets connectés, en passant par l\'activisme des dirigeants sur les réseaux sociaux, l\'exploration des jeux en réseau, ou le défi de l\'information en ligne, cet ouvrage ne se contente pas de dessiner les contours du web aux quatre coins de notre planète. Il revient aussi sur la façon dont Internet modifie en profondeur, et de manière pérenne, le quotidien et les représentations des 5 milliards d\'utilisateurs à travers le monde. Grâce à la collaboration de Tristan Mendès France, spécialiste d\'Internet, et de Quintin Leeds, graphiste hors pair, Internet. Une infographie rend compte des grands enjeux de notre temps : ceux d\'un monde ultra-connecté.',
        'http://books.google.com/books/content?id=NoDpEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        28,
        'Tactique',
        'SO FOOT',
        'Marabout',
        '2021-05-05',
        'Crafts & Hobbies',
        2,
        'Un autre football est-il possible? La France a-t-elle vraiment joué à rien en 2018? Le verrou suisse est-il un mythe ou une réalité? Qu’est-ce que le QI football? Quel rapport existe-t-il entre la densité de population aux Pays-Bas et le football total? Peut-on jouer en sapin de Noël en plein été? Le Special One est-il, au fond, un homme comme les autres? Quel est le rapport entre la Royal Air Force et le football scandinave? Qui a tué le catenaccio italien? L’attaque est-elle réellement la meilleure défense? Les grands joueurs font-ils de grands entraîneurs? Qu’est-ce qu’un coup tactique? De quoi le tiki-taka est-il le nom? Pourquoi le coach le plus culte du monde est un homme qui trimbale sa glacière partout? Mieux vaut-il perdre en jouant bien ou gagner en jouant mal? Et surtout, qui sont les hommes qui pensent le jeu et nous poussent à réfléchir à la façon de pratiquer le football depuis des décennies? Toutes les réponses à ces questions essentielles sont dans Tactique, écoles de jeu, préceptes & origines.',
        'http://books.google.com/books/content?id=C5EtEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        29,
        'Les tabous du foot',
        'Pierre RONDEAU',
        'Solar',
        '2019-02-14',
        'Sports & Recreation',
        1,
        'Toutes les questions qui fâchent sur le foot à l\'épreuve des faits scientifiques Parce qu\'ils sont devenus des stars internationales, les footballeurs sont érigés en modèles. Les moindres de leurs faits et gestes sont épiés, surveillés. La cigarette, l\'alcool, le sexe, le dopage, l\'argent, l\'homosexualité, le racisme, l\'impartialité de l\'arbitrage... autant de sujets qui, officiellement, ne posent aucun problème dans le foot, mais qui alimentent pourtant les fantasmes et les rumeurs incessantes. Alors qu\'en est-il vraiment ? Ces clubs richissimes et ces joueurs millionnaires gèrent-ils si bien leur argent ? Le foot serait-il le seul sport à échapper au dopage ? Le mode de vie des joueurs est-il vraiment différent de celui des autres jeunes gens de leur âge ? Aucun gay dans le foot, est-ce crédible ? Pour répondre à toutes ces interrogations, Pierre Rondeau a enquêté au-delà même des témoignages et s\'est appuyé sur des études scientifiques (économiques, sociologiques ou médicales...). Battant en brèche les idées reçues, il montre que le football n\'est pas ce modèle idyllique érigé derrière des tabous protecteurs.',
        'http://books.google.com/books/content?id=h-SEDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        30,
        'SQL Server 2008',
        'Jérôme Gabillaud',
        'Editions ENI',
        '0000-00-00',
        'Database management',
        1,
        'Aucun résumé disponible',
        'http://books.google.com/books/content?id=Fgd63uHagk8C&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        31,
        'SQL Server 2008',
        'William R. Stanek',
        'Microsoft Press',
        '2009-02-11',
        'Computers',
        1,
        'SQL Server 2008 est la nouvelle version du logiciel phare de Microsoft en matière de développement, d\'administration et de gestion des bases de données. Ce Guide de l\'Administrateur fournit toutes les informations concrètes pour administrer SQL Server 2008 le plus efficacement possible. Les principaux sujets traités sont l\'installation, la configuration et la personnalisation de SQL Server, l\'administration des serveurs, la création des comptes, l\'importation et l\'exportation des données, la mise en oeuvre de la réplication...',
        'http://books.google.com/books/content?id=PbnhSvM_urgC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        32,
        'Feuilles de match',
        'Pierre Pottier',
        'Publishroom',
        '2022-07-06',
        'Sports & Recreation',
        3,
        'Dans un monde sous la menace permanente de l\’effet de sphère, il n’est pas facile de résister à la pollution footballistique. Peuplé d’individus préférant les albums Panini aux livres de la Pléiade, devenu envahissant dans un monde 2.0, on aime reléguer le football dans les basses divisions intellectuelles. Pourtant le football regorge de théories tactiques, de faits historiques, de personnages de roman, de tirades fumantes et d’anecdotes piquantes. Il se joue du ballon comme la littérature se joue des mots, il le manipule, le feinte, trompe l’adversaire pour toucher au but. Terrain de jeu exigeant et rempli de merveilleux solistes, il crée des histoires que le plus créatif des dramaturges ne pourrait imaginer. Feuilles de match fait le petit pont entre ces deux univers qui se connaissent mal et qui gagneraient à se connaitre mieux, afin que le plaisir des mots permette de découvrir les joyaux de la couronne du sport roi. De son positionnement sur le pré à sa place dans la société, 120 histoires vous expliqueront pourquoi la terre est ronde comme un ballon et pourquoi le football mérite de jouer les prolongations.',
        'http://books.google.com/books/content?id=jIJ5EAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        33,
        'Donqui Foot',
        'Hubert Artus',
        'Média Diffusion',
        '2011-07-01',
        'Reference',
        1,
        'Le Donqui Foot passe en revue tout ce qui relie l\'histoire du ballon rond à l\'Histoire des hommes, depuis le jour où les premières règles en furent posées. Grâce à de multiples entrées, il illustre les trois siècles que le football a traversés : le XIXe, celui du \" people\'s game \" aristocratique, devenu sport ouvrier et populaire ; le XXe des footballs nationalistes qui évoluent en sports de masse mondialisés ; enfin, le XXIe du \" foot business \", cette discipline dont les outils, les équipements et la représentation sociale n\'ont plus rien à voir avec les origines. De \" Ajax \" à \" Zoff \" en passant par \" Maradona \", \" Best \", \" Cruyff \", \" OM \", mais aussi par des prismes inattendus comme \" Chaussure \", \" Cocaïne \", \" Église \", \" Entreprise \", \" Femmes \", \" FLN \", \" Ouvriers \", \" Palestine \", \" Syndicats \" ou \" Grève \", ce dictionnaire aussi vulgarisé qu\'érudit dessine l\'histoire et la contre-histoire du football moderne : d\'un perpétuel va-et-vient entre le pied et l\'esprit, alliant enquêtes inédites et récits édifiants basés pour certains sur des entretiens rares (Michel Hidalgo ou Roger Lemerre), il rend compte des liens entre microcosme du terrain et macrocosme du monde. Et permet d\'aborder les rapports que le ballon rond entretient avec les guerres, les luttes contre la colonisation et l\'esclavage, les nationalismes, le racisme et l\'antiracisme ; mais aussi avec le rock, les avancées technologiques, la science, les luttes salariales, ou encore avec la \" pipolisation \". Qui se souvient de la courte guerre qui opposa le Honduras au Salvador à la suite d\'un match de foot ? Qui connaît l\'histoire d\'Adidas ? L\'itinéraire des footballeurs ouvriers de Sedan ? Le drame de Ray Kennedy, l\'un des meilleurs footballeurs anglais ? Qui se rappelle Djamel Zidane, Salah Assad et l\'épopée algérienne qui finit en tragédie ? Qui sait la vraie histoire de la conception d\'un maillot ? Dans des articles précis et souvent originaux, le passionné revivra des instants connus, mais trouvera aussi cocasseries et informations inédites ; le profane, lui, découvrira un monde insoupçonné d\'allégresses collectives, de tragédies et de légendes.',
        'http://books.google.com/books/content?id=LmiI6LpJthMC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        34,
        'Réussir son BAC SES grâce au foot',
        'Pierre Rondeau',
        'Studyrama',
        '2023-09-12',
        'Education',
        1,
        'Pourquoi la star du PSG Kylian Mbappé gagne 6 millions d\'euros par mois alors que le salaire moyen des footballeurs en France n\'est que de 131 000 euros ? La science économique offre-t-elle des solutions et des outils pour corriger ces inégalités ? Ne peut-on pas supposer que le foot promeut un idéal de justice sociale et de solidarité collective ? Ce manuel va chercher à répondre à toutes ces questions, et bien plus encore. En se basant sur le programme de terminale spécialité SES ainsi que les des notions étudiées en première et deuxième année d\'université, « Réussir son bac SES grâce au foot » offre une possibilité unique de comprendre le monde moderne et ses problématiques à partir d\'un exemple simple et connu de tous. Ce livre est destiné à l\'ensemble des lycéens en sciences économiques et sociales, aux étudiants de premier cycle universitaire et à tous les passionnés de foot. Ils apprécieront un ouvrage très accessible, divertissant et intéressant.',
        'http://books.google.com/books/content?id=8ADVEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        35,
        'Premier en foot',
        'Catherine Missonnier',
        'FeniXX',
        '1996-12-31',
        'Juvenile Fiction',
        1,
        'Saïd est premier de la classe. Depuis toujours. Mais il rêve d\'autres succès, et surtout de jouer au foot en participant à de vrais matchs. Sa mère n\'est pas d\'accord et les copains guère enthousiastes. Alors Saïd s\'entraîne en secret. Saura-t-il prouver son talent en remplaçant un joueur indisponible ?',
        'http://books.google.com/books/content?id=s9tXDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        36,
        'Dis pourquoi le foot',
        'Collectif, Willy Richert',
        'Deux Coqs d\'Or',
        '2021-08-25',
        'Juvenile Nonfiction',
        2,
        'Qui a marqué le plus de buts lors de la dernière coupe du monde ? Pourquoi Maradona est-il un joueur mythique ? Pourquoi le foot est-il le sport le plus populaire au monde ? Quel est le record de cartons rouges distribués en un match ? 150 question-réponses ludiques pour devenir incollable sur le foot ! Pour tout découvrir de ses origines, ses records, ses règles du jeu, ses équipes incroyables et ses joueurs de légende, une multitude d\'infos pour se plonger dans l\'univers de ce sport passionnant ! Avec, à la fin de l\'ouvrage, des jeux et des quiz pour tester ses connaissances tout en s\'amusant.',
        'http://books.google.com/books/content?id=4NVHEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        37,
        'SQL Pour les Nuls',
        'Allen G. TAYLOR',
        'First Interactive',
        '2014-02-27',
        'Computers',
        9,
        'Un tour d\'horizon complet de la mise en œuvre de SQL pour tous vos développements Un tour d\'horizon complet de la mise en œuvre de SQL pour tous vos développements Ce nouveau livre de la collection \" Pour les Nuls pros\" va vous donner en quelque 500 pages toutes les connaissances qui vous permettront de maîtriser SQL et de construire des requêtes fiables et puissantes. SQL (Structured Query Language) est un langage qui permet de construire de puissantes bases de données relationnelles. Vous apprendrez toutes les techniques pour concevoir et administrer une base de données, et même à créer des bases de données Internet. Au programme de ce livre : Les bases de données relationnelles, les composantes de SQL, les bases de données relationnelles multitables, manipuler les données, les opérateurs relationnels, les requêtes récursives, sécuriser les bases de données, protéger les données, ODBC et JDBC, SQL et Internet, SQL en Intranet, Dynamic SQL.',
        'http://books.google.com/books/content?id=RLv6AgAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        38,
        'SQL Server 2000',
        'Jérôme Gabillaud',
        'Editions ENI',
        '0000-00-00',
        'Database design',
        5,
        'Aucun résumé disponible',
        'http://books.google.com/books/content?id=_vNEbZ69s_cC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        39,
        'SQL',
        'Frédéric Brouard, Rudi Bruchez, Christian Soutou',
        'Pearson Education France',
        '0000-00-00',
        'Query languages (Computer science)',
        1,
        'Manuel destiné aux étudiants des premier et second cycles universitaires et aux professionnels de la gestion de bases de données. En neuf chapitres accompagnés d\'exercices de révision avec corrigé: Bases de données et SQL; Définition des données; Création des objets; Recherche de l\'information dans une table; Extraction multitabulaire; Mise à jour des données; Transactions et SQL procédural; Sécurité; Informations de schéma. Les principales modifications apportées à cette deuxième édition de l\'ouvrage sont: l\'ajout des règles de Codd; le report des exercices sur le CD-ROM, le livre imprimé ne contenant que la théorie. [SDM].',
        'http://books.google.com/books/content?id=cHwku_GWnaIC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        40,
        'Oracle PL-SQL',
        'Steven Feuerstein, Bill Pribyl',
        'O\'Reilly Media, Inc.',
        '0000-00-00',
        'Inconnue',
        1,
        'Oracle est le gestionnaire de bases de données le plus répandu et PL/SQL joue un rôle crucial dans les produits et applications Oracle présents et à venir. Cette nouvelle édition est bien plus qu\'une mise à jour. Elle couvre toutes les versions jusqu\'à Oracle 9i Release 2 ; vous y découvrirez de nouveaux types de données (comme les XMLType) et les nouvelles fonctionnalités du PL/SQL (le SQL dynamique, les transactions autonomes, les enregistrements basés sur DML, etc...). De nouveaux chapitres enrichissent cette édition : comment créer et faire tourner des programmes PL/SQL, comment appeler des méthodes java depuis le PL/SQL. Ce guide, écrit par un expert reconnu, se divise en six parties une présentation de PL/SQL : introduction au langage, création et exécution de code. La structure des programmes PL/SQL : les contrôles conditionnels et séquentiels, les boucles et les traitements itératifs, les gestionnaires d\'exception. Les données d\'un programme : les manipuler, les chaînes, les nombres, les dates et horodatages, les enregistrements et les collections, les différents types de données. SQL et PL/SQL : la gestion de transaction et DML, l\'extraction des données, le SQL et le PL/SQL dynamique. Le développement d\'applications : les procédures, fonctions et paramètres, les packages, les triggers, la gestion des applications PL/SQL. Les fonctions avancées de PL/SQL : le moteur d\'exécution, les aspects orientés objet du langage, les appels java, les procédures externes. Cet ouvrage s\'adresse à tous les développeurs en PL/SQL ; ils y trouveront une information remise à jour, un guide clair et complet traitant de la création d\'applications avec PL/SQL conformes aux règles de l\'art. L\'ouvrage fourmille de conseils et d\'astuces théoriques et pratiques, expose une gamme de techniques et d\'architectures de codes, ainsi que des exemples complets. L\'auteur, par ses conseils, éloigne le programmeur des écueils qui peuvent surgir à chaque instant.',
        'http://books.google.com/books/content?id=V7g8mSD89mMC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        41,
        'SQL Server 2005',
        'Jérôme Gabillaud',
        'Editions ENI',
        '0000-00-00',
        'Inconnue',
        1,
        'Cet ouvrage est extrait du titre \"SQL Server 2005 -Administration d\'une base de données\" dans la collection Ressources Informatiques aux Editions ENI. Il s\'adresse à un public de lecteurs initiés à la manipulation des données avec SQL Server 2005 et conscients du rôle joué par une base de données dans un programme informatique. Il vous permettra d\'acquérir les compétences nécessaires pour gérer une base de données au quotidien et assurer sa sécurité.',
        'http://books.google.com/books/content?id=sR7K2aBk62sC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        42,
        'SQL Server 2008',
        'William R. Stanek',
        'Microsoft Press',
        '2009-02-11',
        'Computers',
        1,
        'SQL Server 2008 est la nouvelle version du logiciel phare de Microsoft en matière de développement, d\'administration et de gestion des bases de données. Ce Guide de l\'Administrateur fournit toutes les informations concrètes pour administrer SQL Server 2008 le plus efficacement possible. Les principaux sujets traités sont l\'installation, la configuration et la personnalisation de SQL Server, l\'administration des serveurs, la création des comptes, l\'importation et l\'exportation des données, la mise en oeuvre de la réplication...',
        'http://books.google.com/books/content?id=PbnhSvM_urgC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        43,
        'La révolution Internet',
        'Antoine Char, Roch Côté',
        'PUQ',
        '2011-04-22',
        'Social Science',
        2,
        'Il y a un peu plus de 30 ans, la société Apple mettait sur le marché le premier ordinateur personnel destiné au grand public. Qui se doutait à cette époque que cette petite machine, d’usage assez restreint, allait servir de base à un réseau mondial d’échange de données et bouleverser l’univers des médias',
        'http://books.google.com/books/content?id=l78pDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        44,
        'Internet pour les Nuls, 20e',
        'John R. LEVINE, Carol BAROUDI, Margaret LEVINE YOUNG',
        'First Interactive',
        '2020-05-28',
        'Computers',
        1,
        'Le best-seller des livres sur Internet dans sa nouvelle édition + 210 000 ex. vendus ! Vous n\'avez aucune prédisposition naturelle pour les nouvelles technologies informatiques ? Tant mieux ! Internet pour les Nuls va répondre à toutes les questions que vous vous posez : qu\'est-ce qu\'Internet, comment installer mon navigateur, comment me connecter, comment surfer décontracté sur le Web, comment adresser mon courrier électronique (e-mail) à mes correspondants, quelles sont les meilleures \" adresses \", quel fournisseur d\'accès choisir, quel type de connexion, câble, ADSL ? Cette nouvelle édition est entièrement mise à jour pour le navigateur Microsoft Edge et Windows 10. Au programme : On commence par la sécurité Matériel nécessaire pour surfer sur le Net Découverte du navigateur, l\'outil indispensable Partager une connexion Internet Rechercher avec Google Musique et vidéo Acheter et vendre en toute sécurité Télécharger des fichiers Le mail avec Courrier Sécuriser sa connexion avec les outils proposés par Windows 10 Les applications sociales Les messageries en ligne',
        'http://books.google.com/books/content?id=yu_jDwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        45,
        'La Révolution Internet en question',
        'Proulx Serge',
        'Québec Amerique',
        '2013-02-05',
        'Social Science',
        4,
        '« La synthèse et le contenu de cet ouvrage apportent une information très pertinente sur la nature de l\'outil qu\'était Internet et ce qu\'il est devenu. »Hélène Cantin, Radio-Canada, Sonnez les matines, Gaspésie« J\'ignore qui, chez Québec Amérique, a conçu cette collection, mais il faut l\'en féliciter. Par une série de questions, regroupées par thèmes, ces ouvrages initient efficacement le lecteur à un vaste champ de connaissances. (...) Non seulement ce livre pose-t-il de judicieuses questions, mais surtout il fournit des réponses documentées, capables d\'engendrer une réflexion sur nos habitudes d\'internautes. »Jean-François Crépeau, Le Canada français « (...) il retrace la genèse du phénomène Internet, pose quelques « bonnes questions » d’actualité sociologique et soulève bon nombre de réflexions pertinentes. Le tout est bien ficelé et se lit d’une traite, que l’on soit expert sur les histoires d’Internet ou simple néophyte. » Nelson Dumais, Journal de Montréal« Cet ouvrage répond à des questions avec en prime, des tableaux, glossaires, illustrations et repères chronologiques fort utiles. » Inter (Magazine de l’Université du Québec à Montréal)',
        'http://books.google.com/books/content?id=ft9CDwAAQBAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api'
    ),
    (
        46,
        'Internet',
        'Jacques Bonjawo',
        'KARTHALA Editions',
        '2002-01-01',
        'Computer networks',
        4,
        '\" Nous vivons une période de l\'histoire du monde particulièrement mouvementée. Socialement, politiquement, scientifiquement, techniquement, tout évolue rapidement, et la communication instantanée et globale de toute information renforce l\'agitation permanente de nos existences. Décidément, le monde va vite, trop vite. La révolution numérique, plus encore l\'émergence de l\'Internet, a pris tout le monde de court. Cet ouvrage essaie d\'évaluer les chances qu\'apporte cette révolution à un développement véritable du continent africain. Jacques Bonjawo occupe une situation privilégiée qui lui permet d\'analyser ce phénomène sous deux angles complémentaires. Travaillant à Microsoft, temple des nouvelles technologies, il participe en amont à la définition des normes, lesquelles auront un impact direct sur la direction que prendront l\'Internet et les autres technologies de l\'information et des communications (TIC) dans les années à venir. Africain, il est à même de gérer en aval cet impact et d\'en évaluer les bénéfices potentiels pour son continent. \" Patrick Baudry, astronaute-spationaute.',
        'http://books.google.com/books/content?id=pBK3u6z-mmsC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        47,
        'L’Avenir des idées',
        'Lawrence Lessig',
        'Presses universitaires de Lyon',
        '2021-08-09',
        'Language Arts & Disciplines',
        1,
        'L’hostilité de Lawrence Lessig à l’égard des dérives monopolistisques et des excès de la réglementation, notamment celle du droit d’auteur, ne se fonde pas sur des présupposés idéologiques, mais sur une analyse précise, illustrée par de nombreuses études de cas, des conséquences catastrophiques pour l’innovation et la créativité que ne manqueront pas d’avoir les évolutions récentes de l’architecture de l’Internet. De plus en plus fermée, propriétarisée et centralisée, celle-ci est en train de stériliser la prodigieuse inventivité à laquelle l’Internet a pu donner lieu à ses débuts. Historien scrupuleux des trente années de développement de ce moyen de communication interactif, d’échange de connaissances, de création de richesses intellectuelles sans précédent, Lawrence Lessig pose le problème en juriste, mais aussi en philosophe et en politique. C’est une certaine idée du partage des savoirs et de la création artistique qui est en jeu dans les tendances actuelles qui dénaturent les principes démocratiques de l’Internet originel. Cette étude parfaitement documentée est aussi un pressant cri d’alarme.',
        'http://books.google.com/books/content?id=XaD9DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        48,
        'Reconnaissance et usages d’Internet',
        'Fabien Granjon',
        'Presses des MINES',
        '0000-00-00',
        'Language Arts & Disciplines',
        1,
        'Les technologies de l’information et de la communication jouent un rôle de plus en plus essentiel dans la structuration et les transformations de l’ordre social. Ce livre propose une approche critique de cette importance et de la manière dont il est fait aujourd’hui usage d’Internet. Partant de la théorie de la reconnaissance d’Axel Honneth, il montre comment ces usages s’insèrent dans la définition des identités et participent des univers sociaux des sujets. Les pratiques de l’informatique connectée ne peuvent en effet être réduites à la simple manipulation d’artefacts techniques. Elles s’inscrivent dans la matérialité des dispositifs, mais relèvent également des conditions sociales, des sens pratiques et des dispositions des utilisateurs. Ces ajustements sociotechniques peuvent habiliter le sujet, mais également le contraindre. La démonstration s’organise en trois étapes : elle porte d’abord la focale sur les discours accompagnant le développement des TIC et l’émergence de la « société de l’information » ; elle s’intéresse ensuite aux inégalités numériques et aux usages de l’informatique connectée que développent les populations socialement défavorisées ; elle traite, enfin, des pratiques récentes de mise en visibilité et de mise en récit de soi sur Internet.',
        'http://books.google.com/books/content?id=C19nQQlc11sC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        49,
        'Tactique de combat des trois armes',
        'Alexis Henri Brialmont, Alexis Brialmont',
        'Inconnu',
        '0000-00-00',
        'Tactics',
        1,
        'Aucun résumé disponible',
        'http://books.google.com/books/content?id=YG0DAAAAYAAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        50,
        'ANTHROPOLOGIE DU COMBAT',
        'Jean Luc Guinot',
        'BoD - Books on Demand France',
        '2010-09-20',
        'Inconnue',
        4,
        'Ce livre est destiné à donner des outils permettant, de mieux vivre les confrontations et les agressions que la vie ne manquera pas de mettre sur votre chemin, il vous aidera aussi à comprendre les épreuves passées et à établir des stratégies de défense efficaces. L\'agression physique, base même de notre réflexion, est bien sûr très largement abordée, mais nous avons voulu élargir notre exposé, avec les agressions dites psychologiques et notamment l\'inhibition de l\'action, responsable de nombreuses maladies et cause de décès dans de nombreux pays. Ce livre, cet essai littéraire s\'adresse à tous, dans un langage le plus accessible possible pour les non-spécialistes, il est le résultat d\'une recherche, d\'un essai de compréhension d\'un système complexe, puisque vivant, et en évolution permanente. L’auteur de ce livre ne prétend pas détenir la vérité mais, évoque la réalité, il ne propose pas de recettes miracles pour apprendre à se défendre mais, simplement fournir des éléments capables d\'alimenter votre propre réflexion avec l\'espoir de faire de vous des chercheurs, capables de découvrir des voies inexplorées et plus particulièrement celles qui sont enfouies au plus profond de votre cerveau.',
        'http://books.google.com/books/content?id=il29Pz_hU5UC&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        51,
        'Le Combat',
        'Alexandre Percin',
        'Inconnu',
        '2014-10-01',
        'Inconnue',
        1,
        'Le combat / par le General PercinDate de l\'edition originale: 1914Sujet de l\'ouvrage: France -- Histoire militaire\"Collection: Nouvelle collection scientifique\"Ce livre est la reproduction fidele d\'une oeuvre publiee avant 1920 et fait partie d\'une collection de livres reimprimes a la demande editee par Hachette Livre, dans le cadre d\'un partenariat avec la Bibliotheque nationale de France, offrant l\'opportunite d\'acceder a des ouvrages anciens et souvent rares issus des fonds patrimoniaux de la BnF.Les oeuvres faisant partie de cette collection ont ete numerisees par la BnF et sont presentes sur Gallica, sa bibliotheque numerique.En entreprenant de redonner vie a ces ouvrages au travers d\'une collection de livres reimprimes a la demande, nous leur donnons la possibilite de rencontrer un public elargi et participons a la transmission de connaissances et de savoirs parfois difficilement accessibles.Nous avons cherche a concilier la reproduction fidele d\'un livre ancien a partir de sa version numerisee avec le souci d\'un confort de lecture optimal. Nous esperons que les ouvrages de cette nouvelle collection vous apporteront entiere satisfaction.Pour plus d\'informations, rendez-vous sur www.hachettebnf.fr\"',
        'http://books.google.com/books/content?id=bYc4jgEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api'
    ),
    (
        52,
        'Le combat Adama',
        'Geoffroy de Lagasnerie, Assa Traore',
        'Stock',
        '2019-04-03',
        'Social Science',
        1,
        '« Le Combat Adama, ce n’est pas seulement le combat de la famille Traoré. Mon frère est mort sous le poids de trois gendarmes et d’un système. La France a un problème avec la police et la gendarmerie : ça fait partie du Combat Adama. La jeunesse fait partie du Combat Adama. L’école fait partie du Combat Adama. Le racisme fait partie du Combat Adama. La démocratie et la justice font partie du Combat Adama. » Assa Traoré Le 19 juillet 2016, Adama Traoré est mort dans la cour de la gendarmerie de Persan dans le Val-d’Oise. C’était le jour de son anniversaire. Il avait 24 ans. Depuis, un combat se développe et s’amplifie qui, à partir de la question des violences policières dans les quartiers populaires, interroge en profondeur notre monde et la politique : le Combat Adama.',
        'http://books.google.com/books/content?id=_u6ODwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    ),
    (
        53,
        'Bilikat, le beau combat',
        'Michael Müller-Hewer',
        'BoD - Books on Demand',
        '2011-07-01',
        'History',
        5,
        'Le 20 mai 2011, à l\'Université de Paris 13, IUT de Bobigny, avait lieu une table ronde avec le sujet: \"Autour des Gaulois en guerre\". Ce texte de conférence reporte sur 10 ans de recherches sur le combat celtique du groupe CLADIO, groupe de recherche de l\'Université de Lausanne (UNIL). Il présente des hypothèses de travail et des indications sur le maniement des armes celtiques en précisant que c\'est une reconstitution de techniques de combat, sur laquelle existe très peu de traces écrites dans le passé. Les recherches étaient menées dans le cadre de l\'archéologie expérimentale au département Archéologie de l\'UNIL sous la direction du Prof. Thierry Luginbühl.',
        'http://books.google.com/books/content?id=cJreEAAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api'
    );