
const searchInput = document.querySelector("#search");
const searchResults = document.querySelector(".table");

let dataArray;
async function getbooks() {
    const res = await fetch("http://localhost/www/projet%20web%20L2/PHP/recupUserEnpreint.php");
    const results = await res.json();
    //trie la structure en fonction du titre des livres
    dataArray = orderList(results);
    createBookList(dataArray);
}
getbooks();

function orderList(data) {
    const orderedData = data.sort((a, b) => {
        if (a.title.toLowerCase() > b.title.toLowerCase()) {
            return 1;
        } else if (a.title.toLowerCase() < b.title.toLowerCase()) {
            return -1;
        } else {
            return 0;
        }
    });
    return orderedData;
}

function createBookList(bookList) {
    bookList.forEach(loan => {
        const listItem = document.createElement("tr");
        listItem.innerHTML = `
                    <td><img src=${loan.img} alt="image" width="70px" heigth="80px"></td>
                    <td>${loan.title}</td>
                    <td>${loan.start_date}</a></td>
                    <td>${loan.end_date}</td>
                    <td>${loan.qte}</td> 
                    <td><a href="renouveler.php?date=${loan.end_date}&loan_id=${loan.loan_id}" ><img src="../Image/renouveler.png" alt="renouveler" width="50px" heigth="50px"></a></td>
                    <td><a href="rendre.php?loan_id=${loan.loan_id}&book_id=${loan.book_id}&qte=${loan.qte}"><img src="../Image/rendre.png" alt="rendre" width="50px" heigth="50px"></a></td>`;
        searchResults.appendChild(listItem);
    });
}
//trié des qu'on ecrit dans le input
searchInput.addEventListener("input", filterData)

function filterData(e) {
    const searchedString = e.target.value.trim().toLowerCase().replace(/\s/g, ""); // Utiliser trim() pour supprimer les espaces inutiles au début et à la fin

    if (searchedString === "") {
        // Si la chaîne de recherche est vide, réafficher toutes les données
        createBookList(dataArray);
    }
    // Sinon, filtrer les données en fonction de la chaîne de recherche
    const filteredArr = dataArray.filter(loan =>
        loan.title.toLowerCase().includes(searchedString) || loan.author.toLowerCase().includes(searchedString)
        //|| loan.publisher.toLowerCase().includes(searchedString) || loan.publication_year.toLowerCase().includes(searchedString)
        //|| loan.category.toLowerCase().includes(searchedString)
    );

    searchResults.innerHTML = `<table class="table">
                                <tr>
                                    <th>Image</th>
                                    <th>Nom du livre</th>
                                    <th>Date de debut</th>
                                    <th>Date de fin</th>
                                    <th>Quantité</th>
                                    <th>Renouveler</th>
                                    <th>Rendre</th>
                                </tr>
                                </table>`;

    createBookList(filteredArr); // Afficher les résultats filtrés

}
