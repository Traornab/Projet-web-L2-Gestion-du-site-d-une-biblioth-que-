const searchInput = document.querySelector("#search");
const searchResults = document.querySelector(".table");
const element = document.getElementById("seclectTrie");

let dataArray;

async function fetchData(criteria) {
    const res = await fetch("http://localhost/www/projet%20web%20L2/PHP/recup.php");
    const results = await res.json();
    return sortData(results, criteria);
}

function sortData(data, criteria) {
    switch (criteria) {
        case 'titre':
            return data.sort((a, b) => {
                return a.title.toLowerCase().localeCompare(b.title.toLowerCase());
            });
        case 'auteur':
            return data.sort((a, b) => {
                return a.author.toLowerCase().localeCompare(b.author.toLowerCase());
            });
        case 'categorie':
            return data.sort((a, b) => {
                return a.category.toLowerCase().localeCompare(b.category.toLowerCase());
            });
        default:
            return data;
    }
}

async function getAndDisplayData(criteria) {
    dataArray = await fetchData(criteria);
    searchResults.innerHTML = ""; // liberer les données
    createBookList(dataArray);
}

getAndDisplayData('titre'); // Initialement trié par le titre

element.addEventListener("click", () => {
    switch (element.value) {
        case 'titre':
            getAndDisplayData('titre');
            break;
        case 'auteur':
            getAndDisplayData('auteur');
            break;
        case 'categorie':
            getAndDisplayData('categorie');
            break;
        default:
    }
});

function createBookList(bookList) {
    let nbcol = 5;
    let listItem = document.createElement("tr");

    bookList.forEach(book => {
        const id = book.id;
        const cell = document.createElement("td");
        cell.innerHTML = `
        <a href="infoBook.php?id=${id}">
          <img src="${book.img}" width="80px" height="90px">
          <p>${book.title}</p>
        </a>`;

        listItem.appendChild(cell);
        nbcol--;

        if (nbcol === 0) {
            searchResults.appendChild(listItem);
            listItem = document.createElement("tr");
            nbcol = 5;
        }
    });

    if (listItem.children.length > 0) {
        searchResults.appendChild(listItem);
    }
}

//recherche des qu'on ecrit dans le input
searchInput.addEventListener("input", filterData)

function filterData(e) {
    const searchedString = e.target.value.trim().toLowerCase(); // Utiliser trim() pour supprimer les espaces inutiles au début et à la fin

    if (searchedString === "") {
        // Si la chaîne de recherche est vide, réafficher toutes les données
        createBookList(dataArray);
    } else {
        // Sinon, filtrer les données en fonction de la chaîne de recherche
        const filteredArr = dataArray.filter(book =>
            book.title.toLowerCase().includes(searchedString) || book.author.toLowerCase().includes(searchedString)
            || book.category.toLowerCase().includes(searchedString)
        );
        searchResults.innerHTML = ``;
        createBookList(filteredArr); // Afficher les résultats filtrés
    }
}
