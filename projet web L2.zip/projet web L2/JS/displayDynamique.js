/**
 * Tous les autres fichier js commançant par displayDynamique ont la même fonction
 * recuperer les information en format JSON qui seront envoyer d'un fichier php et affichera sous forme de
 * tableau les infoemation resultant, gère aussi la recherche ou filtrage et le trie de manière automatique
 * grâce aux addEventListener. 
 */
const searchInput = document.querySelector("#search");
const searchResults = document.querySelector(".table");
const element = document.getElementById("seclectTrie");

let dataArray;
async function fetchData(criteria) {
    const res = await fetch("http://localhost/www/projet%20web%20L2/PHP/recup.php");
    const results = await res.json();
    return sortData(results, criteria);
}

function sortData(data, criteria) {
    switch (criteria) {
        case 'titre':
            return data.sort((a, b) => {
                return a.title.toLowerCase().localeCompare(b.title.toLowerCase());
            });
        case 'auteur':
            return data.sort((a, b) => {
                return a.author.toLowerCase().localeCompare(b.author.toLowerCase());
            });
        case 'categorie':
            return data.sort((a, b) => {
                return a.category.toLowerCase().localeCompare(b.category.toLowerCase());
            });
        default:
            return data;
    }
}
async function getAndDisplayData(criteria) {
    dataArray = await fetchData(criteria);
    searchResults.innerHTML = `<table class="table">
    <tr>
      <th>Stock</th>
      <th>Titre</th>
      <th>Auteur</th>
      <th>Editeur</th>
      <th>Année de publication</th>
      <th>Catégorie</th>
      <th>Résumé</th>
      <th>Image</th>
    </tr>
  </table>`; // liberer les données
    createBookList(dataArray);
}

getAndDisplayData('titre'); // Initialement trié par le titre

element.addEventListener("click", () => {
    switch (element.value) {
        case 'titre':
            getAndDisplayData('titre');
            break;
        case 'auteur':
            getAndDisplayData('auteur');
            break;
        case 'categorie':
            getAndDisplayData('categorie');
            break;
        default:
    }
});


function createBookList(bookList) {
    bookList.forEach(book => {
        const id = book.id;
        const listItem = document.createElement("tr");
        listItem.innerHTML = `
                    <td><a href="modif.php?id=${id}">${book.stock}</a></td>
                    <td><a href="modif.php?id=${id}">${book.title}</a></td>
                    <td><a href="modif.php?id=${id}">${book.author}</a></td>
                    <td><a href="modif.php?id=${id}">${book.publisher}</a></td>
                    <td><a href="modif.php?id=${id}">${book.publication_year}</a></td> 
                    <td><a href="modif.php?id=${id}">${book.category}</a></td>
                    <td><a href="modif.php?id=${id}"><div class="scrollable-container">${book.Summary}</div></a></td>
                    <td><a href="modif.php?id=${id}"><img src="${book.img}" width="80px" height="90px"></a></td>`;
        searchResults.appendChild(listItem);
    });
}
//recherche des qu'on ecrit dans le input
searchInput.addEventListener("input", filterData)

function filterData(e) {
    const searchedString = e.target.value.trim().toLowerCase(); // Utiliser trim() pour supprimer les espaces inutiles au début et à la fin

    if (searchedString === "") {
        // Si la chaîne de recherche est vide, réafficher toutes les données
        createBookList(dataArray);
    } else {
        // Sinon, filtrer les données en fonction de la chaîne de recherche
        const filteredArr = dataArray.filter(book =>
            book.title.toLowerCase().includes(searchedString) || book.author.toLowerCase().includes(searchedString)
            || book.category.toLowerCase().includes(searchedString)
        );
        searchResults.innerHTML = `<table class="table">
            <tr>
            <th>Stock</th>
            <th>Titre</th>
            <th>Auteur</th>
            <th>Editeur</th>
            <th>Année de publication</th>
            <th>Catégorie</th>
            <th>Résumé</th>
            <th>Image</th>
            </tr>
        </table>`;
        createBookList(filteredArr); // Afficher les résultats filtrés
    }
}
