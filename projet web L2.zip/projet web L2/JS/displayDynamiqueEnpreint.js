
const searchInput = document.querySelector("#search");
const searchResults = document.querySelector(".table");

let dataArray;
async function getbooks() {
    const res = await fetch("http://localhost/www/projet%20web%20L2/PHP/recupEnpreint.php");
    const results = await res.json();
    //trie la structure en fonction du titre des livres
    dataArray = orderList(results);
    createBookList(dataArray);
}
getbooks();

function orderList(data) {
    const orderedData = data.sort((a, b) => {
        if (a.title.toLowerCase() > b.title.toLowerCase()) {
            return 1;
        } else if (a.title.toLowerCase() < b.title.toLowerCase()) {
            return -1;
        } else {
            return 0;
        }
    });
    return orderedData;
}
//a adapter pour les enpreints
function createBookList(bookList) {
    bookList.forEach(loan => {
        const listItem = document.createElement("tr");
        listItem.innerHTML = `
    <td>${loan.title}</td>
    <td>${loan.first_name}</td>
    <td>${loan.last_name}</td>
    <td>${loan.start_date}</td>
    <td>${loan.end_date}</td>
    <td>${loan.qte}</td> 
    <td><img src="${loan.img}" width="80px" height="90px"></td>`;
        searchResults.appendChild(listItem);
    });
}
//trié des qu'on ecrit dans le input
searchInput.addEventListener("input", filterData)

function filterData(e) {
    const searchedString = e.target.value.trim().toLowerCase(); // Utiliser trim() pour supprimer les espaces inutiles au début et à la fin

    if (searchedString === "") {
        // Si la chaîne de recherche est vide, réafficher toutes les données
        createBookList(dataArray);
    } else {
        // Sinon, filtrer les données en fonction de la chaîne de recherche
        const filteredArr = dataArray.filter(book =>
            book.title.toLowerCase().includes(searchedString) || book.author.toLowerCase().includes(searchedString)
            // || book.publisher.toLowerCase().includes(searchedString) || book.publication_year.toLowerCase().includes(searchedString)
            // || book.category.toLowerCase().includes(searchedString)
        );

        searchResults.innerHTML = `<table class="table">
    <tr>
      <th>Stock</th>
      <th>Titre</th>
      <th>Auteur</th>
      <th>Editeur</th>
      <th>Année de publication</th>
      <th>Catégorie</th>
      <th>Résumé</th>
      <th>Image</th>
    </tr>
  </table>`;

        createBookList(filteredArr); // Afficher les résultats filtrés
    }
}

