
const searchInput = document.querySelector("#search");
const searchResults = document.querySelector(".table");

let dataArray;
async function getbooks() {
    const res = await fetch("http://localhost/www/projet%20web%20L2/PHP/recupUser.php");
    const results = await res.json();
    //trie la structure en fonction du titre des livres
    dataArray = orderList(results);
    createBookList(dataArray);
}
getbooks();

function orderList(data) {
    const orderedData = data.sort((a, b) => {
        if (a.first_name.toLowerCase() > b.first_name.toLowerCase()) {
            return 1;
        } else if (a.first_name.toLowerCase() < b.first_name.toLowerCase()) {
            return -1;
        } else {
            return 0;
        }
    });
    return orderedData;
}

function createBookList(bookList) {
    bookList.forEach(user => {
        const listItem = document.createElement("tr");
        listItem.innerHTML = `
                    <td><a href="modifUser.php?id=${user.user_id}">${user.first_name}</a></td>
                    <td><a href="modifUser.php?id=${user.user_id}">${user.last_name}</a></td>
                    <td><a href="modifUser.php?id=${user.user_id}">${user.birth_date}</a></td>
                    <td><a href="modifUser.php?id=${user.user_id}">${user.email}</a></td>
                    <td><a href="modifUser.php?id=${user.user_id}">${user.statue}</a></td> `;
        searchResults.appendChild(listItem);
    });
}
//trié des qu'on ecrit dans le input
searchInput.addEventListener("input", filterData)

function filterData(e) {
    const searchedString = e.target.value.trim().toLowerCase().replace(/\s/g, ""); // Utiliser trim() pour supprimer les espaces inutiles au début et à la fin

    if (searchedString === "") {
        // Si la chaîne de recherche est vide, réafficher toutes les données
        createBookList(dataArray);
    }
    // Sinon, filtrer les données en fonction de la chaîne de recherche
    const filteredArr = dataArray.filter(user =>
        user.first_name.toLowerCase().includes(searchedString) || user.last_name.toLowerCase().includes(searchedString)
        || user.email.toLowerCase().includes(searchedString)
        || user.statue.toLowerCase().includes(searchedString)
        || user.birth_date.toLowerCase().includes(searchedString)
    );

    searchResults.innerHTML = `<table class="table">
        <tr>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Année de naissance</th>
            <th>Email</th>
            <th>Statue</th>
        </tr>
    </table>`;

    createBookList(filteredArr); // Afficher les résultats filtrés

}
